const VERSION = '48';
const CACHE_PREFIX = 'calculo-decaimientos-';
const CACHE_NAME = `${CACHE_PREFIX}v${VERSION}`;
const LEGACY_CACHE_PATTERN = /^actividad-fuentes-v\d+$/;

const REQUIRED_SHELL = [
  './',
  './index.html',
  './styles.css?v=48',
  './app.js?v=48',
  './src/config.js?v=48',
  './src/csv.js?v=48',
  './src/domain.js?v=48',
  './src/format.js?v=48',
  './src/pdf.js?v=48',
  './src/report.js?v=48',
  './src/repository.js?v=48',
  './src/view.js?v=48',
  './inventario_radiactivo.csv?v=48',
  './isotopos.csv?v=48',
  './manifest.webmanifest?v=48',
  './assets/brand/at-logo-horizontal.png?v=48',
  './assets/brand/at-logo-stacked.png?v=48',
  './assets/fonts/Montserrat-SemiBold.ttf?v=48',
  './assets/fonts/Montserrat-Bold.ttf?v=48',
  './assets/fonts/Roboto-Regular.ttf?v=48',
  './assets/fonts/Roboto-Medium.ttf?v=48',
  './assets/vendor/html2canvas-1.4.1.min.js?v=48',
  './assets/vendor/jspdf-4.2.1.umd.min.js?v=48',
  './icons/app-icon.png?v=48',
  './icons/app-icon-192.png?v=48',
  './icons/app-icon-512.png?v=48',
  './icons/app-icon-maskable-512.png?v=48',
  './icons/apple-touch-icon.png?v=48'
];

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(REQUIRED_SHELL);
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names
      .filter(name => (name.startsWith(CACHE_PREFIX) && name !== CACHE_NAME) || LEGACY_CACHE_PATTERN.test(name))
      .map(name => caches.delete(name)));
    if (self.registration.navigationPreload) await self.registration.navigationPreload.disable();
    await self.clients.claim();
  })());
});

self.addEventListener('message', event => {
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
});

async function navigationResponse(event) {
  const cache = await caches.open(CACHE_NAME);
  const cached = (await cache.match('./index.html', { ignoreSearch: true }))
    || (await cache.match('./', { ignoreSearch: true }));
  if (cached) return cached;
  try {
    const response = (await event.preloadResponse) || await fetch(event.request);
    if (response?.ok) await cache.put('./index.html', response.clone());
    return response;
  } catch {
    return Response.error();
  }
}

async function staticResponse(request) {
  const cache = await caches.open(CACHE_NAME);
  const cached = await cache.match(request, { ignoreVary: false });
  if (cached) return cached;
  try {
    const response = await fetch(request);
    if (response.ok && response.type === 'basic') await cache.put(request, response.clone());
    return response;
  } catch {
    return Response.error();
  }
}

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET' || request.headers.has('range')) return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin || !['http:', 'https:'].includes(url.protocol)) return;
  event.respondWith(request.mode === 'navigate' ? navigationResponse(event) : staticResponse(request));
});
