import { APP_VERSION, SCHEMA_VERSION } from './src/config.js?v=48';
import { fetchCsv } from './src/csv.js?v=48';
import {
  normalizeModel,
  parseDateOnly,
  todayIso,
  typeCategory,
  validateInventoryDraft,
  validateIsotopeDraft
} from './src/domain.js?v=48';
import { downloadPdf, createReportPdf } from './src/pdf.js?v=48';
import { buildReport, buildShareText } from './src/report.js?v=48';
import { createRepository } from './src/repository.js?v=48';
import { createView } from './src/view.js?v=48';
import { formatDescriptor } from './src/format.js?v=48';

const repository = createRepository();
const view = createView();

const state = {
  model: { schemaVersion: SCHEMA_VERSION, revision: 0, updatedAt: '', inventory: [], isotopes: [] },
  calculationDate: todayIso(),
  filter: 'all',
  query: '',
  groups: [],
  visibleGroups: [],
  editingRecordId: null,
  editingIsotopeName: '',
  formRevision: 0,
  installPrompt: null,
  reportPrepared: false,
  reportBusy: false,
  serviceWorkerUpdateAccepted: false,
  reloadingForServiceWorker: false
};

const byId = id => document.getElementById(id);

function render() {
  const result = view.renderDashboard(
    state.model,
    state.calculationDate,
    state.filter,
    state.query
  );
  state.groups = result.groups;
  state.visibleGroups = result.visible;
  view.renderIsotopes(state.model.isotopes);
}

function saveModel(nextModel, successMessage) {
  const result = repository.save(nextModel, state.model.revision);
  if (!result.ok) {
    view.toast(result.reason || 'No se pudieron guardar los cambios.');
    return false;
  }
  state.model = result.model;
  render();
  if (successMessage) view.toast(successMessage);
  return true;
}

function setMaterialFields(isMaterial) {
  document.querySelectorAll('.material-field').forEach(label => {
    label.classList.toggle('hidden', !isMaterial);
    const field = label.querySelector('input, select, textarea');
    if (field) field.disabled = !isMaterial;
  });
}

function fillIsotopeSelect(selectedName = '') {
  const select = byId('inventoryIsotope');
  const names = [...state.model.isotopes]
    .map(isotope => isotope.isotopo)
    .sort((first, second) => first.localeCompare(second, 'es'));
  select.replaceChildren(...names.map(name => {
    const option = document.createElement('option');
    option.value = name;
    option.textContent = name;
    return option;
  }));
  if (selectedName && names.includes(selectedName)) select.value = selectedName;
}

function openInventory(recordId = null) {
  const record = recordId
    ? state.model.inventory.find(item => item.record_id === recordId)
    : null;
  state.editingRecordId = record?.record_id || null;
  state.formRevision = state.model.revision;
  const form = view.nodes.inventoryForm;
  form.reset();
  view.clearFormErrors(form, view.nodes.inventoryStatus);
  fillIsotopeSelect(record?.radionuclido || '');

  const isMaterial = record ? typeCategory(record) === 'material' : false;
  byId('inventoryType').value = isMaterial ? 'material_contaminado' : 'fuente_puntual';
  byId('inventoryId').value = record?.identificacion || '';
  if (record?.radionuclido) byId('inventoryIsotope').value = record.radionuclido;
  byId('inventoryReferenceDate').value = record?.fecha_referencia || '';
  byId('inventoryActivity').value = record?.actividad_referencia_bq || '';
  byId('inventoryOperator').value = record?.operador_actividad || '=';
  byId('inventoryMass').value = record?.masa_g || '';
  byId('inventorySpecificActivity').value = record?.actividad_especifica_bq_g || '';
  byId('inventoryUncertainty').value = record?.incertidumbre_actividad_bq || '';
  byId('inventorySpecificUncertainty').value = record?.incertidumbre_especifica_bq_g || '';
  byId('inventoryUncertaintyType').value = formatDescriptor(record?.tipo_incertidumbre);
  byId('inventoryNotes').value = record?.observaciones || '';
  byId('inventoryDialogTitle').textContent = record ? 'Editar registro' : 'Añadir fuente o material';
  byId('saveInventory').textContent = record ? 'Guardar cambios' : 'Añadir';
  setMaterialFields(isMaterial);
  view.openDialog(view.nodes.inventoryDialog, byId('inventoryType'));
}

function closeInventory() {
  view.closeDialog(view.nodes.inventoryDialog);
  state.editingRecordId = null;
}

function inventoryDraft() {
  return {
    tipo: byId('inventoryType').value,
    identificacion: byId('inventoryId').value,
    radionuclido: byId('inventoryIsotope').value,
    fecha_referencia: byId('inventoryReferenceDate').value,
    actividad_referencia_bq: byId('inventoryActivity').value,
    operador_actividad: byId('inventoryOperator').value,
    masa_g: byId('inventoryMass').value,
    actividad_especifica_bq_g: byId('inventorySpecificActivity').value,
    incertidumbre_actividad_bq: byId('inventoryUncertainty').value,
    incertidumbre_especifica_bq_g: byId('inventorySpecificUncertainty').value,
    tipo_incertidumbre: byId('inventoryUncertaintyType').value,
    observaciones: byId('inventoryNotes').value
  };
}

function saveInventory(event) {
  event.preventDefault();
  if (state.formRevision !== state.model.revision) {
    view.showFormError(
      view.nodes.inventoryForm,
      view.nodes.inventoryStatus,
      '',
      'Los datos cambiaron en otra pestaña. Cierra y vuelve a abrir este formulario.'
    );
    return;
  }
  const validation = validateInventoryDraft(
    inventoryDraft(),
    state.model.inventory,
    state.editingRecordId
  );
  if (!validation.ok) {
    view.showFormError(
      view.nodes.inventoryForm,
      view.nodes.inventoryStatus,
      validation.field,
      validation.message
    );
    return;
  }

  const inventory = [...state.model.inventory];
  const existingIndex = inventory.findIndex(record => record.record_id === state.editingRecordId);
  if (existingIndex >= 0) inventory[existingIndex] = validation.record;
  else inventory.push(validation.record);
  const success = saveModel(
    { ...state.model, inventory },
    existingIndex >= 0 ? 'Registro actualizado.' : 'Registro añadido.'
  );
  if (success) closeInventory();
}

function deleteGroup(groupKey) {
  const group = state.groups.find(item => item.key === groupKey);
  if (!group) return;
  const isotopeText = [...new Set(group.records.map(record => record.radionuclido))].join(', ');
  if (!window.confirm(`¿Quitar ${group.id} (${isotopeText})? Esta acción elimina todos sus registros.`)) return;
  const recordIds = new Set(group.records.map(record => record.record_id));
  saveModel(
    { ...state.model, inventory: state.model.inventory.filter(record => !recordIds.has(record.record_id)) },
    'Elemento eliminado.'
  );
}

function openIsotopes() {
  cancelIsotopeEdit();
  view.renderIsotopes(state.model.isotopes);
  view.openDialog(view.nodes.isotopesDialog, byId('addIsotope'));
}

function startIsotopeEdit(name = '') {
  const isotope = state.model.isotopes.find(item => item.isotopo === name);
  state.editingIsotopeName = isotope?.isotopo || '';
  state.formRevision = state.model.revision;
  byId('isotopeForm').reset();
  view.clearFormErrors(byId('isotopeForm'), view.nodes.isotopeStatus);
  byId('isotopeEditorTitle').textContent = isotope ? `Editar ${isotope.isotopo}` : 'Añadir isótopo';
  byId('isotopeName').value = isotope?.isotopo || '';
  byId('isotopeName').disabled = Boolean(isotope);
  byId('isotopeHalfLife').value = isotope?.semivida_valor || '';
  byId('isotopeUnit').value = isotope?.semivida_unidad || 'anos';
  byId('isotopeSource').value = isotope?.fuente || '';
  view.nodes.isotopeEditor.classList.remove('hidden');
  requestAnimationFrame(() => (isotope ? byId('isotopeHalfLife') : byId('isotopeName')).focus());
}

function cancelIsotopeEdit() {
  state.editingIsotopeName = '';
  byId('isotopeName').disabled = false;
  byId('isotopeForm').reset();
  view.clearFormErrors(byId('isotopeForm'), view.nodes.isotopeStatus);
  view.nodes.isotopeEditor.classList.add('hidden');
}

function saveIsotope(event) {
  event.preventDefault();
  if (state.formRevision !== state.model.revision) {
    view.showFormError(
      byId('isotopeForm'),
      view.nodes.isotopeStatus,
      '',
      'Los datos cambiaron en otra pestaña. Vuelve a abrir el editor.'
    );
    return;
  }
  const validation = validateIsotopeDraft({
    isotopo: byId('isotopeName').value,
    semivida_valor: byId('isotopeHalfLife').value,
    semivida_unidad: byId('isotopeUnit').value,
    fuente: byId('isotopeSource').value
  }, state.model.isotopes, state.editingIsotopeName);
  if (!validation.ok) {
    view.showFormError(
      byId('isotopeForm'),
      view.nodes.isotopeStatus,
      validation.field,
      validation.message
    );
    return;
  }

  const isotopes = [...state.model.isotopes];
  const existingIndex = isotopes.findIndex(item => item.isotopo === state.editingIsotopeName);
  if (existingIndex >= 0) isotopes[existingIndex] = validation.isotope;
  else isotopes.push(validation.isotope);
  if (saveModel(
    { ...state.model, isotopes },
    existingIndex >= 0 ? 'Isótopo actualizado.' : 'Isótopo añadido.'
  )) {
    view.renderIsotopes(state.model.isotopes);
    cancelIsotopeEdit();
  }
}

function deleteIsotope(name) {
  if (state.model.inventory.some(record => record.radionuclido === name)) {
    view.showStatus(view.nodes.isotopeStatus, `No se puede quitar ${name}: está utilizado por uno o más registros.`, true);
    return;
  }
  if (!window.confirm(`¿Quitar el isótopo ${name}?`)) return;
  if (saveModel(
    { ...state.model, isotopes: state.model.isotopes.filter(isotope => isotope.isotopo !== name) },
    'Isótopo eliminado.'
  )) view.renderIsotopes(state.model.isotopes);
}

function reportGroups() {
  return byId('reportVisibleOnly').checked ? state.visibleGroups : state.groups;
}

function prepareReport() {
  const groups = reportGroups();
  buildReport(view.nodes.printReportView, groups, state.model.isotopes, state.calculationDate, byId('reportVisibleOnly').checked);
  state.reportPrepared = true;
  view.showStatus(view.nodes.reportStatus, groups.length ? '' : 'No hay elementos para incluir.', !groups.length);
  return groups;
}

function setReportBusy(busy) {
  state.reportBusy = busy;
  view.nodes.reportDialog.setAttribute('aria-busy', String(busy));
  ['cancelReport', 'closeReport', 'shareReport', 'downloadReport'].forEach(id => {
    byId(id).disabled = busy;
  });
}

async function generateReportFile() {
  const groups = prepareReport();
  if (!groups.length) return null;
  view.showStatus(view.nodes.reportStatus, 'Generando el PDF local…');
  return createReportPdf(view.nodes.printReportView, state.calculationDate);
}

async function downloadReport() {
  if (state.reportBusy) return;
  setReportBusy(true);
  try {
    const result = await generateReportFile();
    if (!result) return;
    downloadPdf(result.blob, result.filename);
    view.closeDialog(view.nodes.reportDialog);
    view.toast('Informe PDF generado y descargado.');
  } catch (error) {
    view.showStatus(view.nodes.reportStatus, `No se pudo generar el PDF: ${error.message}`, true);
  } finally {
    setReportBusy(false);
  }
}

async function copyText(text) {
  if (navigator.clipboard?.writeText && window.isSecureContext) {
    await navigator.clipboard.writeText(text);
    return;
  }
  const area = document.createElement('textarea');
  area.value = text;
  area.setAttribute('readonly', '');
  area.className = 'clipboard-fallback';
  document.body.append(area);
  area.select();
  const copied = document.execCommand?.('copy');
  area.remove();
  if (!copied) throw new Error('El navegador no admite la copia automática.');
}

function canSharePdfFile(file) {
  if (!file || typeof navigator.share !== 'function' || typeof navigator.canShare !== 'function') return false;
  try {
    return navigator.canShare({ files: [file] });
  } catch {
    return false;
  }
}

async function shareReport() {
  if (state.reportBusy) return;
  setReportBusy(true);
  try {
    const groups = reportGroups();
    const result = await generateReportFile();
    if (!result) return;
    const text = buildShareText(groups, state.model.isotopes, state.calculationDate);
    const canShareFile = canSharePdfFile(result.file);
    if (canShareFile) {
      await navigator.share({
        title: 'Cálculo de actividades',
        text: `Informe con fecha de cálculo ${state.calculationDate}.`,
        files: [result.file]
      });
      view.toast('Informe PDF compartido.');
    } else {
      downloadPdf(result.blob, result.filename);
      await copyText(text).catch(() => {});
      view.toast('Este navegador no comparte archivos directamente. Se ha descargado el PDF.');
    }
    view.closeDialog(view.nodes.reportDialog);
  } catch (error) {
    if (error?.name !== 'AbortError') view.showStatus(view.nodes.reportStatus, `No se pudo compartir: ${error.message}`, true);
  } finally {
    setReportBusy(false);
  }
}

function synchronizeExternalData() {
  const external = repository.readExternal(state.model.isotopes);
  if (!external.ok || external.model.revision <= state.model.revision) return;
  state.model = external.model;
  render();
  view.toast('Datos actualizados desde otra pestaña.');
}

function showServiceWorkerUpdate(registration) {
  if (!registration.waiting) return;
  view.nodes.updateBanner.classList.remove('hidden');
  byId('updateButton').onclick = () => {
    if (!registration.waiting) return;
    state.serviceWorkerUpdateAccepted = true;
    registration.waiting.postMessage({ type: 'SKIP_WAITING' });
  };
}

async function setupServiceWorker() {
  if (!('serviceWorker' in navigator) || !window.isSecureContext) return;
  try {
    const registration = await navigator.serviceWorker.register(`./sw.js?v=${APP_VERSION}`);
    showServiceWorkerUpdate(registration);
    registration.addEventListener('updatefound', () => {
      const worker = registration.installing;
      worker?.addEventListener('statechange', () => {
        if (worker.state === 'installed' && navigator.serviceWorker.controller) showServiceWorkerUpdate(registration);
      });
    });
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (!state.serviceWorkerUpdateAccepted) return;
      if (state.reloadingForServiceWorker) return;
      state.reloadingForServiceWorker = true;
      window.location.reload();
    });
  } catch (error) {
    console.warn('El modo sin conexión no pudo iniciarse.', error);
  }
}

function setupInstallPrompt() {
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    state.installPrompt = event;
    byId('installButton').classList.remove('hidden');
  });
  window.addEventListener('appinstalled', () => {
    state.installPrompt = null;
    byId('installButton').classList.add('hidden');
    view.toast('Aplicación instalada.');
  });
}

function activateTab(tab) {
  state.filter = tab.dataset.filter;
  document.querySelectorAll('.tab').forEach(item => {
    const active = item === tab;
    item.classList.toggle('active', active);
    item.setAttribute('aria-selected', String(active));
    item.tabIndex = active ? 0 : -1;
  });
  render();
}

function setupEvents() {
  view.nodes.calculationDate.addEventListener('change', event => {
    if (!parseDateOnly(event.target.value)) {
      event.target.value = state.calculationDate;
      view.toast('Introduce una fecha de cálculo válida.');
      return;
    }
    state.calculationDate = event.target.value;
    state.reportPrepared = false;
    render();
  });
  view.nodes.searchInput.addEventListener('input', event => {
    state.query = event.target.value;
    render();
  });
  document.querySelector('.tabs').addEventListener('click', event => {
    const tab = event.target.closest('.tab');
    if (tab) activateTab(tab);
  });
  document.querySelector('.tabs').addEventListener('keydown', event => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    const tabs = [...document.querySelectorAll('.tab')];
    const current = tabs.indexOf(document.activeElement);
    let next = current;
    if (event.key === 'ArrowRight') next = (current + 1) % tabs.length;
    if (event.key === 'ArrowLeft') next = (current - 1 + tabs.length) % tabs.length;
    if (event.key === 'Home') next = 0;
    if (event.key === 'End') next = tabs.length - 1;
    event.preventDefault();
    tabs[next].focus();
    activateTab(tabs[next]);
  });

  byId('inventoryButton').addEventListener('click', () => openInventory());
  byId('isotopesButton').addEventListener('click', openIsotopes);
  byId('reportButton').addEventListener('click', () => {
    byId('reportVisibleOnly').checked = false;
    state.reportPrepared = false;
    view.showStatus(view.nodes.reportStatus);
    view.openDialog(view.nodes.reportDialog, byId('reportVisibleOnly'));
  });
  byId('installButton').addEventListener('click', async () => {
    if (!state.installPrompt) return;
    try {
      await state.installPrompt.prompt();
      await state.installPrompt.userChoice;
    } catch (error) {
      view.toast(`No se pudo iniciar la instalación: ${error.message}`);
    } finally {
      state.installPrompt = null;
      byId('installButton').classList.add('hidden');
    }
  });

  view.nodes.sourceList.addEventListener('click', event => {
    const action = event.target.closest('[data-action]');
    if (!action) return;
    if (action.dataset.action === 'edit-record') openInventory(action.dataset.recordId);
    if (action.dataset.action === 'delete-group') deleteGroup(action.dataset.groupKey);
  });
  byId('inventoryType').addEventListener('change', event => setMaterialFields(event.target.value === 'material_contaminado'));
  view.nodes.inventoryForm.addEventListener('submit', saveInventory);
  byId('closeInventory').addEventListener('click', closeInventory);
  byId('cancelInventory').addEventListener('click', closeInventory);
  byId('closeIsotopes').addEventListener('click', () => view.closeDialog(view.nodes.isotopesDialog));
  byId('addIsotope').addEventListener('click', () => startIsotopeEdit());
  byId('cancelIsotopeEdit').addEventListener('click', cancelIsotopeEdit);
  byId('isotopeForm').addEventListener('submit', saveIsotope);
  view.nodes.isotopeTable.addEventListener('click', event => {
    const action = event.target.closest('[data-action]');
    if (!action) return;
    if (action.dataset.action === 'edit-isotope') startIsotopeEdit(action.dataset.isotope);
    if (action.dataset.action === 'delete-isotope') deleteIsotope(action.dataset.isotope);
  });
  byId('closeReport').addEventListener('click', () => view.closeDialog(view.nodes.reportDialog));
  byId('cancelReport').addEventListener('click', () => view.closeDialog(view.nodes.reportDialog));
  byId('reportVisibleOnly').addEventListener('change', () => { state.reportPrepared = false; });
  byId('shareReport').addEventListener('click', shareReport);
  byId('downloadReport').addEventListener('click', downloadReport);

  [view.nodes.inventoryDialog, view.nodes.isotopesDialog, view.nodes.reportDialog].forEach(dialog => {
    dialog.addEventListener('cancel', event => {
      event.preventDefault();
      view.closeDialog(dialog);
      if (dialog === view.nodes.inventoryDialog) state.editingRecordId = null;
    });
    dialog.addEventListener('click', event => {
      if (event.target === dialog) view.closeDialog(dialog);
    });
  });
  window.addEventListener('online', () => view.toast('Conexión restablecida.'));
  window.addEventListener('offline', () => view.toast('Sin conexión. La aplicación seguirá usando los datos locales.'));
  repository.subscribe(synchronizeExternalData);
}

async function loadDefaults() {
  const [inventoryResult, isotopeResult] = await Promise.allSettled([
    fetchCsv(`./inventario_radiactivo.csv?v=${APP_VERSION}`),
    fetchCsv(`./isotopos.csv?v=${APP_VERSION}`)
  ]);
  if (inventoryResult.status !== 'fulfilled' || isotopeResult.status !== 'fulfilled') {
    const messages = [inventoryResult, isotopeResult]
      .filter(result => result.status === 'rejected')
      .map(result => result.reason?.message || String(result.reason));
    throw new Error(`No se pudieron cargar los datos incluidos. ${messages.join(' ')}`);
  }
  const normalized = normalizeModel({
    schemaVersion: SCHEMA_VERSION,
    revision: 0,
    updatedAt: '',
    inventory: inventoryResult.value,
    isotopes: isotopeResult.value
  }, isotopeResult.value);
  if (!normalized.ok) throw new Error(`Los datos incluidos no son válidos. ${normalized.warnings.join(' ')}`);
  return normalized.model;
}

async function bootstrap() {
  setupEvents();
  setupInstallPrompt();
  view.nodes.calculationDate.value = state.calculationDate;
  const defaults = await loadDefaults();
  const loaded = repository.load(defaults);
  state.model = loaded.model;
  if (loaded.source !== 'primary') {
    const persisted = repository.persistRecovered(state.model);
    if (persisted.ok) state.model = persisted.model;
    else loaded.warnings.push(persisted.reason);
  }
  render();
  const warnings = [...loaded.warnings];
  if (!repository.persistent) warnings.push('El almacenamiento local está bloqueado: los cambios durarán solo hasta cerrar esta pestaña.');
  if (warnings.length) view.toast(warnings.join(' '), 9_000);
  await setupServiceWorker();
}

bootstrap().catch(error => {
  console.error(error);
  view.nodes.emptyState.classList.remove('hidden');
  view.nodes.emptyTitle.textContent = 'No se pudo iniciar la aplicación';
  view.nodes.emptyMessage.textContent = error.message || 'Se produjo un error inesperado.';
  view.toast('Error de inicio. Recarga la página o revisa el servidor local.', 12_000);
});
