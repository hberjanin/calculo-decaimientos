const PDF_MIME = 'application/pdf';
const PAGE_WIDTH_MM = 297;
const PAGE_HEIGHT_MM = 210;

function libraryFunctions() {
  const html2canvas = globalThis.html2canvas;
  const JsPdf = globalThis.jspdf?.jsPDF;
  if (typeof html2canvas !== 'function' || typeof JsPdf !== 'function') {
    throw new Error('No se pudieron cargar los componentes locales del generador PDF.');
  }
  return { html2canvas, JsPdf };
}

async function waitForImage(image) {
  if (typeof image.decode === 'function') {
    try {
      await image.decode();
      return;
    } catch {
      // El evento de carga proporciona un segundo intento compatible.
    }
  }
  if (image.complete) return;
  await new Promise(resolve => {
    image.addEventListener('load', resolve, { once: true });
    image.addEventListener('error', resolve, { once: true });
  });
}

async function waitForReportAssets(container) {
  await Promise.all([...container.querySelectorAll('img')].map(waitForImage));
  if (document.fonts?.ready) await document.fonts.ready;
  await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
}

function reportOverflowReason(page) {
  const tolerance = 2;
  if (page.clientWidth <= 0 || page.clientHeight <= 0) return 'no tiene dimensiones medibles';
  if (page.scrollHeight > page.clientHeight + tolerance || page.scrollWidth > page.clientWidth + tolerance) {
    return 'desborda los límites A4';
  }

  const reportColumns = page.querySelector('.report-columns');
  if (!reportColumns) return 'no contiene el área de tarjetas';
  const contentRect = reportColumns.getBoundingClientRect();
  const columns = [...page.querySelectorAll('.report-column')];
  for (let columnIndex = 0; columnIndex < columns.length; columnIndex += 1) {
    const column = columns[columnIndex];
    if (column.scrollHeight > reportColumns.clientHeight + tolerance || column.scrollWidth > column.clientWidth + tolerance) {
      return `desborda la columna ${columnIndex + 1}`;
    }
    const columnRect = column.getBoundingClientRect();
    let previousBottom = contentRect.top;
    for (const card of column.querySelectorAll('.report-card')) {
      const cardRect = card.getBoundingClientRect();
      const clipped = cardRect.top < contentRect.top - tolerance
        || cardRect.left < columnRect.left - tolerance
        || cardRect.right > columnRect.right + tolerance
        || cardRect.bottom > contentRect.bottom + tolerance;
      if (clipped) return `recorta una tarjeta en la columna ${columnIndex + 1}`;
      if (cardRect.top < previousBottom - tolerance) return `solapa tarjetas en la columna ${columnIndex + 1}`;
      previousBottom = cardRect.bottom;
    }
  }
  return '';
}

function assertReportFits(pages) {
  pages.forEach((page, index) => {
    const reason = reportOverflowReason(page);
    if (reason) {
      throw new Error(`La página ${index + 1} del informe ${reason}. Reduce la selección o revisa los datos.`);
    }
  });
}

export function reportFilename(calculationDate) {
  const safeDate = /^\d{4}-\d{2}-\d{2}$/.test(calculationDate) ? calculationDate : 'sin-fecha';
  return `calculo-actividades-${safeDate}.pdf`;
}

export async function createReportPdf(container, calculationDate) {
  const { html2canvas, JsPdf } = libraryFunctions();
  const pages = [...container.querySelectorAll('.report-page')];
  if (!pages.length) throw new Error('El informe no contiene páginas para exportar.');

  container.setAttribute('aria-hidden', 'true');
  const captureStage = document.createElement('div');
  captureStage.className = 'pdf-capture-stage';
  captureStage.setAttribute('aria-hidden', 'true');
  document.body.append(captureStage);
  try {
    const pdf = new JsPdf({
      orientation: 'landscape',
      unit: 'mm',
      format: 'a4',
      compress: true,
      putOnlyUsedFonts: true
    });
    pdf.setProperties({
      title: 'Cálculo de actividades',
      subject: `Fecha de cálculo: ${calculationDate}`,
      author: 'Aplicaciones Tecnológicas',
      creator: 'Cálculo de decaimientos'
    });

    // Dos píxeles por píxel CSS mantienen nítido el texto impreso sin agotar
    // la memoria de móviles y tabletas con pantallas de alta densidad.
    const scale = 2;
    for (let index = 0; index < pages.length; index += 1) {
      const page = pages[index].cloneNode(true);
      captureStage.replaceChildren(page);
      await waitForReportAssets(captureStage);
      assertReportFits([page]);
      const canvas = await html2canvas(page, {
        allowTaint: false,
        backgroundColor: '#ffffff',
        foreignObjectRendering: false,
        imageTimeout: 10_000,
        logging: false,
        removeContainer: true,
        scale,
        useCORS: false,
        width: page.clientWidth,
        height: page.clientHeight,
        windowWidth: page.clientWidth,
        windowHeight: page.clientHeight
      });
      if (index > 0) pdf.addPage('a4', 'landscape');
      const image = canvas.toDataURL('image/png');
      pdf.addImage(image, 'PNG', 0, 0, PAGE_WIDTH_MM, PAGE_HEIGHT_MM, undefined, 'FAST');
      canvas.width = 1;
      canvas.height = 1;
    }

    const blob = pdf.output('blob');
    if (!(blob instanceof Blob) || blob.size < 1_000) throw new Error('El archivo PDF generado está vacío.');
    const filename = reportFilename(calculationDate);
    let file = null;
    try {
      file = new File([blob], filename, { type: PDF_MIME, lastModified: Date.now() });
    } catch {
      // File no está disponible en algunos navegadores antiguos; la descarga con Blob sigue funcionando.
    }
    return { blob, file, filename };
  } finally {
    captureStage.remove();
  }
}

export function downloadPdf(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.rel = 'noopener';
  link.className = 'generated-download';
  document.body.append(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
}
