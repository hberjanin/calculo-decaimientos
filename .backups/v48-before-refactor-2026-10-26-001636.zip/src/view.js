import { calculateDecay, filterGroups, groupInventory, groupTitle, groupTypeLabel, toFiniteNumber, typeCategory } from './domain.js?v=48';
import {
  formatActivity,
  formatDate,
  formatDescriptor,
  formatNumber,
  halfLifeLabel,
  halfLifeUnitLabel,
  shouldShowUncertainty,
  toleranceBounds
} from './format.js?v=48';

export function element(tagName, options = {}, children = []) {
  const node = document.createElement(tagName);
  if (options.className) node.className = options.className;
  if (options.text != null) node.textContent = String(options.text);
  if (options.type) node.type = options.type;
  if (options.value != null) node.value = options.value;
  if (options.attributes) for (const [name, value] of Object.entries(options.attributes)) node.setAttribute(name, value);
  if (options.dataset) for (const [name, value] of Object.entries(options.dataset)) node.dataset[name] = value;
  for (const child of Array.isArray(children) ? children : [children]) if (child != null) node.append(child);
  return node;
}

function requiredElement(id) {
  const node = document.getElementById(id);
  if (!node) throw new Error(`Falta el elemento de interfaz #${id}.`);
  return node;
}

function activityText(value, isLimit = false) {
  const activity = formatActivity(value);
  return `${isLimit ? '< ' : ''}${activity.value} ${activity.unit}`;
}

function activityIntervalText(bounds, specific = false) {
  if (!bounds) return '';
  if (specific) return `${formatNumber(bounds.lower, 3)} a ${formatNumber(bounds.upper, 3)} Bq/g`;
  return `${activityText(bounds.lower)} a ${activityText(bounds.upper)}`;
}

function appendDetail(container, text) {
  if (text) container.append(element('small', { text }));
}

function measurementLine(value, uncertainty = '', className = '') {
  const valueClass = ['measurement-value', className].filter(Boolean).join(' ');
  const children = [element('strong', { className: valueClass, text: value })];
  if (uncertainty) children.push(element('span', { className: 'measurement-uncertainty', text: `± ${uncertainty}` }));
  return element('div', { className: 'measurement-line' }, children);
}

function valueBlock(label, measurements, details = []) {
  const lines = Array.isArray(measurements) ? measurements : [measurements];
  const block = element('div', { className: 'value-block' }, [element('span', { text: label }), ...lines]);
  details.filter(Boolean).forEach(detail => appendDetail(block, detail));
  return block;
}

function recordRow(record, isotope, calculationDate) {
  const result = calculateDecay(record, isotope, calculationDate);
  const showUncertainty = shouldShowUncertainty(record);
  const heading = element('div', { className: 'nuclide-name' }, [
    element('strong', { text: record.radionuclido }),
    element('small', { text: `T½ ${halfLifeLabel(isotope)}` }),
    element('button', {
      className: 'inline-action', type: 'button', text: 'Editar registro',
      dataset: { action: 'edit-record', recordId: record.record_id },
      attributes: { 'aria-label': `Editar ${record.radionuclido} de ${record.identificacion}` }
    })
  ]);

  let currentBlock;
  if (!result.available) {
    currentBlock = valueBlock(
      `Actividad a ${formatDate(calculationDate)}`,
      measurementLine('No calculable', '', 'unavailable-value'),
      [result.reason]
    );
  } else {
    const details = [];
    const measurements = [measurementLine(
      activityText(result.activity, result.isLimit),
      showUncertainty && result.currentUncertainty != null ? activityText(result.currentUncertainty) : '',
      result.isLimit ? 'limit-value' : ''
    )];
    if (result.specificActivity != null) {
      measurements.push(measurementLine(
        `${result.isLimit ? '< ' : ''}${formatNumber(result.specificActivity, 3)} Bq/g`,
        showUncertainty && result.currentSpecificUncertainty != null ? `${formatNumber(result.currentSpecificUncertainty, 3)} Bq/g` : '',
        result.isLimit ? 'limit-value' : ''
      ));
    }
    const currentTolerance = toleranceBounds(record, result.factor);
    const currentSpecificTolerance = toleranceBounds(record, result.factor, true);
    if (currentTolerance) details.push(`Intervalo calculado: ${activityIntervalText(currentTolerance)}`);
    if (currentSpecificTolerance) details.push(`Intervalo específico calculado: ${activityIntervalText(currentSpecificTolerance, true)}`);
    currentBlock = valueBlock(`Actividad a ${formatDate(calculationDate)}`, measurements, details);
  }

  const referenceMeasurements = [measurementLine(
    activityText(result.reference, result.isLimit),
    showUncertainty && result.uncertainty != null ? activityText(result.uncertainty) : '',
    result.isLimit ? 'limit-value' : ''
  )];
  const referenceDetails = [];
  if (result.specific != null) {
    referenceMeasurements.push(measurementLine(
      `${result.isLimit ? '< ' : ''}${formatNumber(result.specific, 3)} Bq/g`,
      showUncertainty && result.specificUncertainty != null ? `${formatNumber(result.specificUncertainty, 3)} Bq/g` : '',
      result.isLimit ? 'limit-value' : ''
    ));
  }
  if (record.tipo_incertidumbre) referenceDetails.push(formatDescriptor(record.tipo_incertidumbre));
  const referenceTolerance = toleranceBounds(record);
  const referenceSpecificTolerance = toleranceBounds(record, 1, true);
  if (referenceTolerance) referenceDetails.push(`Intervalo de referencia: ${activityIntervalText(referenceTolerance)}`);
  if (referenceSpecificTolerance) referenceDetails.push(`Intervalo específico de referencia: ${activityIntervalText(referenceSpecificTolerance, true)}`);
  const referenceBlock = valueBlock(
    `Valor de referencia · ${formatDate(record.fecha_referencia)}`,
    referenceMeasurements,
    referenceDetails
  );
  return element('div', { className: 'nuclide-row' }, [heading, currentBlock, referenceBlock]);
}

function sourceCard(group, isotopeMap, calculationDate) {
  const heading = element('div', { className: 'card-heading' }, [
    element('h3', { text: groupTitle(group) }),
    element('span', { className: 'type-badge', text: groupTypeLabel(group) })
  ]);
  const remove = element('button', {
    className: 'small-button danger card-remove', type: 'button', text: 'Quitar',
    dataset: { action: 'delete-group', groupKey: group.key },
    attributes: { 'aria-label': `Quitar ${groupTitle(group)}` }
  });
  const header = element('header', {}, [heading, remove]);
  const rows = group.records.map(record => recordRow(record, isotopeMap.get(record.radionuclido), calculationDate));
  const mass = toFiniteNumber(group.records[0]?.masa_g);
  const metadata = element('div', { className: 'metadata' }, [
    element('div', {}, [element('span', { text: 'Identificador' }), element('strong', { text: group.id })]),
    element('div', {}, [element('span', { text: 'Masa' }), element('strong', { text: mass == null ? 'No aplica' : `${formatNumber(mass, 2)} g` })]),
    element('div', {}, [element('span', { text: 'Contenido' }), element('strong', { text: group.records.length === 1 ? '1 isótopo' : `${group.records.length} isótopos` })])
  ]);
  return element('article', { className: `source-card ${group.category}` }, [header, ...rows, metadata]);
}

export function createView() {
  const nodes = {
    calculationDate: requiredElement('calculationDate'), dateSummary: requiredElement('dateSummary'), searchInput: requiredElement('searchInput'),
    summary: requiredElement('summary'), sourceList: requiredElement('sourceList'), emptyState: requiredElement('emptyState'), emptyTitle: requiredElement('emptyTitle'), emptyMessage: requiredElement('emptyMessage'),
    listTitle: requiredElement('listTitle'), resultCount: requiredElement('resultCount'), countAll: requiredElement('countAll'), countPoint: requiredElement('countPoint'), countMaterial: requiredElement('countMaterial'),
    inventoryDialog: requiredElement('inventoryDialog'), inventoryForm: requiredElement('inventoryForm'), inventoryStatus: requiredElement('inventoryStatus'),
    isotopesDialog: requiredElement('isotopesDialog'), isotopeTable: requiredElement('isotopeTable'), isotopeEditor: requiredElement('isotopeEditor'), isotopeStatus: requiredElement('isotopeStatus'),
    reportDialog: requiredElement('reportDialog'), reportStatus: requiredElement('reportStatus'), printReportView: requiredElement('printReportView'),
    toast: requiredElement('toast'), updateBanner: requiredElement('updateBanner')
  };
  const previousFocus = new WeakMap();
  let toastTimer;

  function renderDashboard(model, calculationDate, filter, query) {
    const groups = groupInventory(model.inventory);
    const visible = filterGroups(groups, filter, query);
    const isotopeMap = new Map(model.isotopes.map(isotope => [isotope.isotopo, isotope]));
    const pointCount = groups.filter(group => group.category === 'point').length;
    const materialCount = groups.filter(group => group.category === 'material').length;
    nodes.countAll.textContent = String(groups.length);
    nodes.countPoint.textContent = String(pointCount);
    nodes.countMaterial.textContent = String(materialCount);
    nodes.listTitle.textContent = filter === 'point' ? 'Fuentes puntuales' : filter === 'material' ? 'Material contaminado' : 'Todos los elementos';
    nodes.resultCount.textContent = visible.length === 1 ? '1 elemento visible' : `${visible.length} elementos visibles`;

    nodes.summary.replaceChildren(
      element('div', { className: 'summary-item' }, [element('span', { text: 'Fuentes puntuales' }), element('strong', { text: pointCount })]),
      element('div', { className: 'summary-item' }, [element('span', { text: 'Materiales' }), element('strong', { text: materialCount })])
    );
    nodes.sourceList.replaceChildren(...visible.map(group => sourceCard(group, isotopeMap, calculationDate)));
    nodes.emptyState.classList.toggle('hidden', visible.length > 0);
    if (!visible.length) {
      const emptyInventory = groups.length === 0;
      nodes.emptyTitle.textContent = emptyInventory ? 'Aún no hay registros' : query ? 'Sin coincidencias' : 'No hay elementos de este tipo';
      nodes.emptyMessage.textContent = emptyInventory ? 'Añade una fuente o material contaminado para comenzar.' : query ? 'Revisa el isótopo o identificador buscado.' : 'Selecciona otro filtro o añade un registro.';
    }

    const today = todayDateValue();
    const selected = dateValue(calculationDate);
    const difference = today && selected ? Math.round((selected - today) / 86_400_000) : null;
    nodes.dateSummary.textContent = difference == null ? 'Selecciona una fecha válida' : difference === 0 ? 'Actividad calculada para hoy' : difference > 0 ? `${difference} días después de hoy` : `${Math.abs(difference)} días antes de hoy`;
    return { groups, visible };
  }

  function renderIsotopes(isotopes) {
    const table = element('table', { className: 'isotope-table' });
    table.append(element('thead', {}, [element('tr', {}, ['Isótopo', 'Semivida', 'Unidad', 'Fuente', 'Acciones'].map(text => element('th', { text, attributes: { scope: 'col' } }))) ]));
    const body = element('tbody');
    [...isotopes].sort((a, b) => a.isotopo.localeCompare(b.isotopo, 'es')).forEach(isotope => {
      const actions = element('div', { className: 'isotope-actions' }, [
        element('button', { className: 'small-button', type: 'button', text: 'Editar', dataset: { action: 'edit-isotope', isotope: isotope.isotopo }, attributes: { 'aria-label': `Editar ${isotope.isotopo}` } }),
        element('button', { className: 'small-button danger', type: 'button', text: 'Quitar', dataset: { action: 'delete-isotope', isotope: isotope.isotopo }, attributes: { 'aria-label': `Quitar ${isotope.isotopo}` } })
      ]);
      body.append(element('tr', {}, [
        element('th', { text: isotope.isotopo, attributes: { scope: 'row' } }),
        element('td', { text: formatNumber(Number(isotope.semivida_valor), Number(isotope.semivida_valor) > 10_000 ? 0 : 4) }),
        element('td', { text: halfLifeUnitLabel(isotope.semivida_unidad) }),
        element('td', { text: isotope.fuente || '—' }),
        element('td', {}, [actions])
      ]));
    });
    table.append(body);
    nodes.isotopeTable.replaceChildren(table);
  }

  function openDialog(dialog, focusTarget) {
    if (dialog.open) {
      requestAnimationFrame(() => focusTarget?.focus());
      return;
    }
    previousFocus.set(dialog, document.activeElement);
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else { dialog.setAttribute('open', ''); dialog.classList.add('dialog-fallback'); document.body.classList.add('modal-open'); }
    requestAnimationFrame(() => focusTarget?.focus());
  }

  function closeDialog(dialog) {
    if (typeof dialog.close === 'function' && dialog.open) dialog.close(); else dialog.removeAttribute('open');
    dialog.classList.remove('dialog-fallback');
    if (!document.querySelector('dialog[open]')) document.body.classList.remove('modal-open');
    const target = previousFocus.get(dialog);
    if (target?.isConnected) requestAnimationFrame(() => target.focus());
  }

  function toast(message, duration = 5_000) {
    clearTimeout(toastTimer);
    nodes.toast.textContent = message;
    nodes.toast.classList.remove('hidden');
    toastTimer = setTimeout(() => nodes.toast.classList.add('hidden'), duration);
  }

  function showStatus(node, message = '', error = false) {
    node.textContent = message;
    node.classList.toggle('hidden', !message);
    node.classList.toggle('error', error);
  }

  function clearFormErrors(form, status) {
    showStatus(status);
    form.querySelectorAll('[aria-invalid="true"]').forEach(field => { field.removeAttribute('aria-invalid'); field.removeAttribute('aria-describedby'); });
  }

  function showFormError(form, status, fieldId, message) {
    clearFormErrors(form, status);
    showStatus(status, message, true);
    const field = document.getElementById(fieldId);
    if (field) { field.setAttribute('aria-invalid', 'true'); field.setAttribute('aria-describedby', status.id); field.focus(); }
  }

  return { nodes, renderDashboard, renderIsotopes, openDialog, closeDialog, toast, showStatus, clearFormErrors, showFormError };
}

function dateValue(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(0); date.setUTCHours(12, 0, 0, 0); date.setUTCFullYear(year, month - 1, day);
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day ? date : null;
}

function todayDateValue() {
  const now = new Date();
  return dateValue(`${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`);
}
