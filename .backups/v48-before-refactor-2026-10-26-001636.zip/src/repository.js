import {
  APP_VERSION,
  LEGACY_INVENTORY_KEY,
  LEGACY_ISOTOPES_KEY,
  LEGACY_VERSION_KEY,
  SCHEMA_VERSION,
  STORAGE_BACKUP_KEY,
  STORAGE_KEY
} from './config.js?v=48';
import { normalizeModel } from './domain.js?v=48';

const LEGACY_SCHEMA_VERSION = 1;

function normalizedDescriptor(value) {
  return String(value ?? '').replaceAll('_', ' ').toLowerCase().replace(/\s+/g, ' ').trim();
}

function migrateLegacyInventory(inventory) {
  if (!Array.isArray(inventory)) return inventory;
  return inventory.map(record => {
    const descriptor = normalizedDescriptor(record?.tipo_incertidumbre);
    const activity = Number(record?.actividad_referencia_bq);
    const uncertainty = Number(record?.incertidumbre_actividad_bq);
    const isLegacyEstimate = descriptor === 'estimada 5 por ciento'
      && record?.radionuclido === 'Eu-152'
      && (
        record?.identificacion === '1105141' && activity === 31857 && uncertainty === 1592.85
        || record?.identificacion === '411068' && activity === 33707 && uncertainty === 1685.35
      );
    if (isLegacyEstimate) {
      return {
        ...record,
        incertidumbre_actividad_bq: '',
        incertidumbre_especifica_bq_g: '',
        tipo_incertidumbre: 'incertidumbre_no_indicada_en_el_certificado'
      };
    }
    const isLegacySteelLimit = record?.identificacion === 'O21121_7'
      && record?.radionuclido === 'Co-60'
      && descriptor === 'limite superior con incertidumbre estimada 10 por ciento';
    return isLegacySteelLimit ? { ...record, tipo_incertidumbre: 'limite_superior' } : record;
  });
}

function migrateCandidateSchema(candidate) {
  if (!candidate || typeof candidate !== 'object') return null;
  if (candidate.schemaVersion === SCHEMA_VERSION) return { candidate, migrated: false };
  if (candidate.schemaVersion !== LEGACY_SCHEMA_VERSION) return null;
  return {
    migrated: true,
    candidate: {
      ...candidate,
      schemaVersion: SCHEMA_VERSION,
      inventory: migrateLegacyInventory(candidate.inventory)
    }
  };
}

function parseJson(value) {
  if (!value) return null;
  try { return JSON.parse(value); } catch { return null; }
}

function read(storage, key) {
  try { return storage.getItem(key); } catch { return null; }
}

function write(storage, key, value) {
  try { storage.setItem(key, value); return true; } catch { return false; }
}

function remove(storage, key) {
  try { storage.removeItem(key); } catch { /* El almacenamiento puede estar bloqueado. */ }
}

function memoryStorage() {
  const values = new Map();
  return {
    getItem: key => values.has(key) ? values.get(key) : null,
    setItem: (key, value) => values.set(key, String(value)),
    removeItem: key => values.delete(key)
  };
}

function resolveStorage(candidate) {
  try {
    const storage = candidate ?? globalThis.localStorage;
    const probe = '__calculo_decaimientos_probe__';
    storage.setItem(probe, '1');
    storage.removeItem(probe);
    return { storage, persistent: true };
  } catch {
    return { storage: memoryStorage(), persistent: false };
  }
}

export function createRepository(candidateStorage) {
  const resolved = resolveStorage(candidateStorage);
  const storage = resolved.storage;
  function normalizeCandidate(candidate, defaultIsotopes) {
    const migrated = migrateCandidateSchema(candidate);
    if (!migrated) return { ok: false, warnings: [] };
    const normalized = normalizeModel(migrated.candidate, defaultIsotopes);
    return { ...normalized, migrated: migrated.migrated };
  }

  function load(defaultModel) {
    const warnings = [];
    const defaultResult = normalizeModel(defaultModel, defaultModel.isotopes);
    if (!defaultResult.ok) throw new Error('Los datos incluidos con la aplicación no son válidos.');

    const primaryRaw = read(storage, STORAGE_KEY);
    const primary = normalizeCandidate(parseJson(primaryRaw), defaultResult.model.isotopes);
    if (primary.ok) {
      const migrationWarning = primary.migrated
        ? ['Se han retirado estimaciones internas que no figuraban en los certificados.']
        : [];
      return {
        model: primary.model,
        source: primary.migrated ? 'migrated' : 'primary',
        warnings: [...primary.warnings, ...migrationWarning]
      };
    }
    if (primaryRaw) warnings.push('Los datos principales estaban dañados o eran incompatibles.');

    const backupRaw = read(storage, STORAGE_BACKUP_KEY);
    const backup = normalizeCandidate(parseJson(backupRaw), defaultResult.model.isotopes);
    if (backup.ok) {
      warnings.push('Se ha recuperado la última copia local válida.');
      return {
        model: backup.model,
        source: backup.migrated ? 'migrated-backup' : 'backup',
        warnings: [...warnings, ...backup.warnings]
      };
    }
    if (backupRaw) warnings.push('La copia local tampoco era válida.');

    const legacyInventoryRaw = read(storage, LEGACY_INVENTORY_KEY);
    const legacyIsotopesRaw = read(storage, LEGACY_ISOTOPES_KEY);
    const legacyInventory = parseJson(legacyInventoryRaw);
    const legacyIsotopes = parseJson(legacyIsotopesRaw);
    if (Array.isArray(legacyInventory) || Array.isArray(legacyIsotopes)) {
      const legacy = normalizeModel({
        schemaVersion: SCHEMA_VERSION,
        revision: 0,
        updatedAt: '',
        inventory: Array.isArray(legacyInventory) ? migrateLegacyInventory(legacyInventory) : defaultResult.model.inventory,
        isotopes: Array.isArray(legacyIsotopes) ? legacyIsotopes : defaultResult.model.isotopes
      }, defaultResult.model.isotopes);
      if (legacy.ok) {
        warnings.push('Se han migrado los datos guardados por la versión anterior.');
        return { model: legacy.model, source: 'legacy', warnings: [...warnings, ...legacy.warnings] };
      }
      warnings.push('Los datos de la versión anterior no se pudieron recuperar.');
    }

    warnings.push('Se han cargado los datos originales de la aplicación.');
    return { model: defaultResult.model, source: 'default', warnings: [...warnings, ...defaultResult.warnings] };
  }

  function currentRevision(defaultIsotopes) {
    const current = normalizeCandidate(parseJson(read(storage, STORAGE_KEY)), defaultIsotopes);
    return current.ok ? current.model.revision : null;
  }

  function save(model, expectedRevision = model.revision, { force = false } = {}) {
    const normalized = normalizeModel(model, model.isotopes);
    if (!normalized.ok) return { ok: false, reason: 'Los datos que se intentan guardar no son válidos.' };

    const persistedRevision = currentRevision(normalized.model.isotopes);
    if (!force && persistedRevision != null && persistedRevision !== expectedRevision) {
      return { ok: false, conflict: true, reason: 'Los datos cambiaron en otra pestaña. Reabre el formulario antes de guardar.' };
    }

    const next = {
      ...normalized.model,
      schemaVersion: SCHEMA_VERSION,
      revision: Math.max(expectedRevision, persistedRevision ?? 0) + 1,
      updatedAt: new Date().toISOString()
    };
    const previous = read(storage, STORAGE_KEY);
    if (previous) write(storage, STORAGE_BACKUP_KEY, previous);
    if (!write(storage, STORAGE_KEY, JSON.stringify(next))) {
      return { ok: false, reason: 'El navegador no ha permitido guardar. Se conserva la versión anterior.' };
    }

    // Mantener estas claves facilita volver temporalmente a una versión anterior.
    write(storage, LEGACY_INVENTORY_KEY, JSON.stringify(next.inventory));
    write(storage, LEGACY_ISOTOPES_KEY, JSON.stringify(next.isotopes));
    write(storage, LEGACY_VERSION_KEY, APP_VERSION);
    return { ok: true, model: next, warnings: normalized.warnings };
  }

  function persistRecovered(model) {
    const result = save(model, model.revision, { force: true });
    if (result.ok) remove(storage, STORAGE_BACKUP_KEY);
    return result;
  }

  function readExternal(defaultIsotopes) {
    return normalizeCandidate(parseJson(read(storage, STORAGE_KEY)), defaultIsotopes);
  }

  function subscribe(callback) {
    if (!globalThis.addEventListener) return () => {};
    const handler = event => { if (event.key === STORAGE_KEY && event.newValue) callback(); };
    globalThis.addEventListener('storage', handler);
    return () => globalThis.removeEventListener('storage', handler);
  }

  return { load, save, persistRecovered, readExternal, subscribe, persistent: resolved.persistent };
}
