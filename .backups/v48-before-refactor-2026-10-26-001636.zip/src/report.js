import { DAYS_PER_YEAR } from './config.js?v=48';
import { calculateDecay, groupTitle, toFiniteNumber } from './domain.js?v=48';
import {
  formatActivity,
  formatDate,
  formatDescriptor,
  formatNumber,
  halfLifeLabel,
  shouldShowUncertainty,
  toleranceBounds
} from './format.js?v=48';
import { element } from './view.js?v=48';

// La capacidad representa espacio vertical aproximado, no número de registros.
// El A4 horizontal dispone de tres columnas; los materiales, tolerancias y
// notas metrológicas consumen más unidades que una fuente sencilla.
const COLUMN_COUNT = 3;
const COLUMN_CAPACITY = 31;
const PAGE_CAPACITY = COLUMN_COUNT * COLUMN_CAPACITY;

function activityText(value, isLimit = false) {
  const formatted = formatActivity(value);
  return `${isLimit ? '< ' : ''}${formatted.value} ${formatted.unit}`;
}

function activityIntervalText(bounds, specific = false) {
  if (!bounds) return '';
  if (specific) return `${formatNumber(bounds.lower, 3)} a ${formatNumber(bounds.upper, 3)} Bq/g`;
  return `${activityText(bounds.lower)} a ${activityText(bounds.upper)}`;
}

function reportMeasurement(value, uncertainty = '', isLimit = false) {
  const children = [element('strong', {
    className: `report-value${isLimit ? ' report-limit' : ''}`,
    text: value
  })];
  if (uncertainty) children.push(element('span', { className: 'report-uncertainty', text: `± ${uncertainty}` }));
  return element('div', { className: 'report-measurement' }, children);
}

function reportMetric(label, measurements, details = [], current = false) {
  const content = Array.isArray(measurements) ? measurements : [measurements];
  const node = element('div', { className: `report-metric${current ? ' report-current' : ''}` }, [
    element('span', { className: 'report-metric-label', text: label }),
    ...content
  ]);
  details.filter(Boolean).forEach(text => node.append(element('small', { text })));
  return node;
}

function reportRecord(record, isotope, calculationDate) {
  const result = calculateDecay(record, isotope, calculationDate);
  const showUncertainty = shouldShowUncertainty(record);
  const referenceMeasurements = [reportMeasurement(
    activityText(result.reference, result.isLimit),
    showUncertainty && result.uncertainty != null ? activityText(result.uncertainty) : '',
    result.isLimit
  )];
  if (result.specific != null) {
    referenceMeasurements.push(reportMeasurement(
      `${result.isLimit ? '< ' : ''}${formatNumber(result.specific, 3)} Bq/g`,
      showUncertainty && result.specificUncertainty != null ? `${formatNumber(result.specificUncertainty, 3)} Bq/g` : '',
      result.isLimit
    ));
  }

  const referenceDetails = [];
  if (record.tipo_incertidumbre) referenceDetails.push(formatDescriptor(record.tipo_incertidumbre));
  const referenceTolerance = toleranceBounds(record);
  const referenceSpecificTolerance = toleranceBounds(record, 1, true);
  if (referenceTolerance) referenceDetails.push(`Intervalo de referencia: ${activityIntervalText(referenceTolerance)}`);
  if (referenceSpecificTolerance) referenceDetails.push(`Intervalo específico de referencia: ${activityIntervalText(referenceSpecificTolerance, true)}`);

  let currentMetric;
  if (!result.available) {
    currentMetric = reportMetric(
      `Actividad a ${formatDate(calculationDate)}`,
      reportMeasurement('No calculable'),
      [result.reason],
      true
    );
  } else {
    const currentMeasurements = [reportMeasurement(
      activityText(result.activity, result.isLimit),
      showUncertainty && result.currentUncertainty != null ? activityText(result.currentUncertainty) : '',
      result.isLimit
    )];
    if (result.specificActivity != null) {
      currentMeasurements.push(reportMeasurement(
        `${result.isLimit ? '< ' : ''}${formatNumber(result.specificActivity, 3)} Bq/g`,
        showUncertainty && result.currentSpecificUncertainty != null
          ? `${formatNumber(result.currentSpecificUncertainty, 3)} Bq/g`
          : '',
        result.isLimit
      ));
    }
    const currentDetails = [];
    const currentTolerance = toleranceBounds(record, result.factor);
    const currentSpecificTolerance = toleranceBounds(record, result.factor, true);
    if (currentTolerance) currentDetails.push(`Intervalo calculado: ${activityIntervalText(currentTolerance)}`);
    if (currentSpecificTolerance) currentDetails.push(`Intervalo específico calculado: ${activityIntervalText(currentSpecificTolerance, true)}`);
    currentMetric = reportMetric(
      `Actividad a ${formatDate(calculationDate)}`,
      currentMeasurements,
      currentDetails,
      true
    );
  }

  const heading = element('div', { className: 'report-nuclide-heading' }, [
    element('strong', { text: record.radionuclido }),
    element('span', { text: `T½ ${halfLifeLabel(isotope)}` })
  ]);
  const referenceMetric = reportMetric(
    `Valor de referencia · ${formatDate(record.fecha_referencia)}`,
    referenceMeasurements,
    referenceDetails
  );
  return element('section', { className: 'report-nuclide' }, [
    heading,
    element('div', { className: 'report-metrics' }, [currentMetric, referenceMetric])
  ]);
}

function reportCard(group, isotopeMap, calculationDate) {
  const mass = toFiniteNumber(group.records[0]?.masa_g);
  const meta = [];
  if (mass != null) meta.push(element('span', { className: 'report-chip report-chip-mass', text: `Masa · ${formatNumber(mass, 2)} g` }));
  meta.push(element('span', {
    className: `report-chip report-chip-${group.category}`,
    text: group.category === 'point' ? 'Fuente puntual' : 'Material contaminado'
  }));
  const header = element('header', { className: 'report-card-head' }, [
    element('h3', { text: groupTitle(group) }),
    element('div', { className: 'report-card-meta' }, meta)
  ]);
  const records = group.records.map(record => reportRecord(
    record,
    isotopeMap.get(record.radionuclido),
    calculationDate
  ));
  return element('article', {
    className: `report-card report-card-${group.category}`,
    dataset: { groupKey: group.key }
  }, [header, ...records]);
}

function recordUnits(record, category) {
  let units = category === 'material' ? 6 : 4;
  if (record.tipo_incertidumbre) units += 1;
  if (toleranceBounds(record)) units += 2;
  if (toleranceBounds(record, 1, true)) units += 2;
  return units;
}

function groupUnits(group) {
  const contentUnits = group.records.reduce(
    (sum, record) => sum + recordUnits(record, group.category),
    0
  );
  return Math.min(COLUMN_CAPACITY, 3 + contentUnits);
}

function splitIntoPages(entries) {
  const totalUnits = entries.reduce((sum, entry) => sum + entry.units, 0);
  const pageCount = Math.max(1, Math.ceil(totalUnits / PAGE_CAPACITY));
  if (pageCount === 1) return [entries];

  let best = null;
  const target = totalUnits / pageCount;
  const evaluate = pages => {
    const units = pages.map(page => page.reduce((sum, entry) => sum + entry.units, 0));
    const overflow = units.reduce((sum, value) => sum + Math.max(0, value - PAGE_CAPACITY), 0);
    const imbalance = units.reduce((sum, value) => sum + ((value - target) ** 2), 0);
    const score = (overflow * 1_000_000) + imbalance;
    if (!best || score < best.score) best = { score, pages: pages.map(page => [...page]) };
  };
  const partition = (start, remainingPages, pages) => {
    if (remainingPages === 1) {
      evaluate([...pages, entries.slice(start)]);
      return;
    }
    const lastSplit = entries.length - remainingPages + 1;
    for (let split = start + 1; split <= lastSplit; split += 1) {
      partition(split, remainingPages - 1, [...pages, entries.slice(start, split)]);
    }
  };
  partition(0, pageCount, []);
  return best.pages;
}

function balanceColumns(entries) {
  const emptyColumn = () => ({ units: 0, entries: [] });
  if (entries.length <= COLUMN_COUNT) {
    const columns = entries.map(entry => ({ units: entry.units, entries: [entry] }));
    while (columns.length < COLUMN_COUNT) columns.push(emptyColumn());
    return columns;
  }

  let best = null;
  for (let firstSplit = 1; firstSplit < entries.length - 1; firstSplit += 1) {
    for (let secondSplit = firstSplit + 1; secondSplit < entries.length; secondSplit += 1) {
      const segments = [
        entries.slice(0, firstSplit),
        entries.slice(firstSplit, secondSplit),
        entries.slice(secondSplit)
      ];
      const units = segments.map(segment => segment.reduce((sum, entry) => sum + entry.units, 0));
      const overflow = units.reduce((sum, value) => sum + Math.max(0, value - COLUMN_CAPACITY), 0);
      const spread = Math.max(...units) - Math.min(...units);
      const score = (overflow * 1_000) + spread;
      if (!best || score <= best.score) best = { score, segments, units };
    }
  }

  return best.segments.map((segment, index) => ({ units: best.units[index], entries: segment }));
}

function packGroups(groups) {
  return ['point', 'material'].flatMap(category => {
    const entries = groups
      .map((group, index) => ({ group, index, units: groupUnits(group) }))
      .filter(entry => entry.group.category === category);
    if (!entries.length) return [];
    const categoryPages = splitIntoPages(entries);
    return categoryPages.map((pageEntries, pageIndex) => ({
      category,
      categoryPage: pageIndex + 1,
      categoryPageCount: categoryPages.length,
      columns: balanceColumns(pageEntries),
      groups: pageEntries.map(entry => entry.group)
    }));
  });
}

function reportHeader(calculationDate, counts, visibleOnly) {
  const details = [
    `${counts.total} elementos`,
    `${counts.isotopes} isótopos`,
    visibleOnly ? 'Selección filtrada' : 'Inventario completo'
  ].join(' · ');
  return element('header', { className: 'report-head' }, [
    element('div', { className: 'report-brand' }, [
      element('img', {
        className: 'report-logo',
        attributes: {
          src: 'assets/brand/at-logo-horizontal.png?v=48',
          alt: 'Aplicaciones Tecnológicas · Radiation Protection & Medical'
        }
      })
    ]),
    element('div', { className: 'report-title' }, [
      element('h1', { text: 'Cálculo de actividades' }),
      element('p', { text: `Fecha de cálculo · ${formatDate(calculationDate)}` }),
      element('span', { text: details })
    ])
  ]);
}

function reportFooter() {
  return element('footer', { className: 'report-footer' }, [
    element('p', {
      text: `A(t) = A₀ × 2^(-(t-t₀)/T½) · 1 año = ${String(DAYS_PER_YEAR).replace('.', ',')} días · “<” indica límite superior.`
    }),
    element('span', { className: 'report-page-number' })
  ]);
}

function pageSummary(groups, category, categoryPage, categoryPageCount) {
  const singular = category === 'point' ? 'fuente' : 'muestra';
  const plural = category === 'point' ? 'fuentes' : 'muestras';
  const itemLabel = groups.length === 1 ? singular : plural;
  return `En esta página: ${groups.length} ${itemLabel} · sección ${categoryPage} de ${categoryPageCount}`;
}

function reportPages(groups, isotopeMap, calculationDate, counts, visibleOnly) {
  return packGroups(groups).map((packedPage, index) => {
    const columns = packedPage.columns.map(column => element('div', { className: 'report-column' },
      column.entries.map(entry => reportCard(entry.group, isotopeMap, calculationDate))
    ));
    const category = packedPage.category;
    const baseTitle = category === 'point' ? 'Fuentes puntuales' : 'Muestras contaminadas';
    const sectionTitle = packedPage.categoryPage > 1 ? `${baseTitle} · continuación` : baseTitle;
    return element('section', {
      className: `report-page report-page-${category}`,
      dataset: { category, reportPage: String(index + 1) }
    }, [
      reportHeader(calculationDate, counts, visibleOnly),
      element('div', { className: 'report-section-heading' }, [
        element('h2', { text: sectionTitle }),
        element('span', {
          text: pageSummary(
            packedPage.groups,
            category,
            packedPage.categoryPage,
            packedPage.categoryPageCount
          )
        })
      ]),
      element('div', { className: 'report-columns' }, columns),
      reportFooter()
    ]);
  });
}

export function buildReport(container, groups, isotopes, calculationDate, visibleOnly) {
  const isotopeMap = new Map(isotopes.map(isotope => [isotope.isotopo, isotope]));
  const counts = {
    total: groups.length,
    isotopes: new Set(groups.flatMap(group => group.records.map(record => record.radionuclido))).size
  };
  const pages = reportPages(groups, isotopeMap, calculationDate, counts, visibleOnly);
  pages.forEach((page, index) => {
    page.querySelector('.report-page-number').textContent = `Página ${index + 1} de ${pages.length}`;
  });
  const documentNode = element('article', {
    className: 'report-document',
    attributes: { 'aria-label': 'Informe de cálculo de actividades' }
  }, pages);
  container.replaceChildren(documentNode);
  return { pageCount: pages.length, cardCount: groups.length };
}

export function buildShareText(groups, isotopes, calculationDate) {
  const isotopeMap = new Map(isotopes.map(isotope => [isotope.isotopo, isotope]));
  const lines = groups.flatMap(group => group.records.map(record => {
    const result = calculateDecay(record, isotopeMap.get(record.radionuclido), calculationDate);
    if (!result.available) return `${groupTitle(group)}: no calculable (${result.reason})`;
    let text = `${record.identificacion} · ${record.radionuclido}: ${activityText(result.activity, result.isLimit)}`;
    if (shouldShowUncertainty(record) && result.currentUncertainty != null) {
      text += ` ± ${activityText(result.currentUncertainty)}`;
    }
    if (result.specificActivity != null) {
      text += ` · ${result.isLimit ? '< ' : ''}${formatNumber(result.specificActivity, 3)} Bq/g`;
      if (shouldShowUncertainty(record) && result.currentSpecificUncertainty != null) {
        text += ` ± ${formatNumber(result.currentSpecificUncertainty, 3)} Bq/g`;
      }
    }
    const descriptor = formatDescriptor(record.tipo_incertidumbre);
    if (descriptor) text += ` · ${descriptor}`;
    const bounds = toleranceBounds(record, result.factor);
    if (bounds) text += ` · intervalo calculado: ${activityIntervalText(bounds)}`;
    return text;
  }));
  return `APLICACIONES TECNOLÓGICAS · RADIATION PROTECTION & MEDICAL\n\nCálculo de actividades\nFecha de cálculo: ${formatDate(calculationDate)}\n\n${lines.join('\n')}\n\nDocumento generado localmente con Cálculo de decaimientos.`;
}
