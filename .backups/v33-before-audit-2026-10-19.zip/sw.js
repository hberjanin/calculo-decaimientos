const CACHE_PREFIX = 'calculo-decaimientos-';
const CACHE = `${CACHE_PREFIX}v33`;
const LEGACY_CACHE_PATTERN = /^actividad-fuentes-v\d+$/;
const ASSETS = [
  './',
  './index.html',
  './styles.css?v=33',
  './app.js?v=33',
  './manifest.webmanifest?v=33',
  './assets/brand/at-logo-horizontal.png?v=33',
  './assets/brand/at-logo-stacked.png?v=33',
  './assets/fonts/Montserrat-SemiBold.ttf',
  './assets/fonts/Montserrat-Bold.ttf',
  './assets/fonts/Roboto-Regular.ttf',
  './assets/fonts/Roboto-Medium.ttf',
  './icons/app-icon.png?v=33',
  './icons/app-icon-192.png?v=33',
  './icons/app-icon-512.png?v=33',
  './icons/app-icon-maskable-512.png?v=33',
  './icons/apple-touch-icon.png?v=33',
  './inventario_radiactivo.csv',
  './isotopos.csv'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => (key.startsWith(CACHE_PREFIX) && key !== CACHE) || LEGACY_CACHE_PATTERN.test(key)).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

async function navigationResponse(request) {
  const cache = await caches.open(CACHE);
  try {
    const response = await fetch(request);
    if (response.ok) {
      await cache.put('./index.html', response.clone());
      return response;
    }
  } catch {
    // The cached shell below is the intended offline fallback.
  }
  return (await cache.match('./index.html', { ignoreSearch: true })) || (await cache.match('./', { ignoreSearch: true })) || Response.error();
}

async function assetResponse(request) {
  if (request.headers.has('range')) return fetch(request);
  const cache = await caches.open(CACHE);
  const cached = await cache.match(request);
  if (cached) return cached;
  const response = await fetch(request);
  if (response.ok) {
    await cache.put(request, response.clone());
  }
  return response;
}

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  event.respondWith(request.mode === 'navigate' ? navigationResponse(request) : assetResponse(request));
});
