param(
    [ValidateRange(1, 65535)]
    [int]$Port = 8080,

    [ValidateNotNullOrEmpty()]
    [string]$BindAddress = '127.0.0.1'
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot

if (Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue) {
    Write-Error "El puerto $Port ya esta ocupado. Prueba con otro, por ejemplo: .\server.ps1 -Port 8081"
    exit 1
}

$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    $python = Get-Command py -ErrorAction SilentlyContinue
}

if (-not $python) {
    Write-Error 'No se ha encontrado Python. Instala Python 3 o inicia otro servidor HTTP en esta carpeta.'
    exit 1
}

Set-Location -LiteralPath $root
$url = if ($BindAddress -eq '0.0.0.0') { "http://127.0.0.1:$Port" } else { "http://${BindAddress}:$Port" }

Write-Host ''
Write-Host 'Calculo de decaimientos' -ForegroundColor Green
Write-Host "Abre la aplicacion en: $url"
if ($BindAddress -eq '0.0.0.0') {
    $addresses = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
        Select-Object -ExpandProperty IPAddress -Unique
    foreach ($address in $addresses) {
        Write-Host "Vista previa en la red local: http://${address}:$Port"
    }
    Write-Warning 'La instalacion PWA y el modo sin conexion en otros dispositivos requieren publicar la aplicacion mediante HTTPS.'
}
Write-Host 'Pulsa Ctrl+C para detener el servidor.' -ForegroundColor DarkGray
Write-Host ''

if ($python.Name -eq 'py.exe') {
    & $python.Source -3 -m http.server $Port --bind $BindAddress
} else {
    & $python.Source -m http.server $Port --bind $BindAddress
}
