const DAY_MS = 86_400_000;
const YEAR_DAYS = 365.2425;
const STORAGE_INVENTORY = 'actividad-inventario';
const STORAGE_ISOTOPES = 'actividad-isotopos';
const STORAGE_DATA_VERSION = 'actividad-datos-version';
const DATA_VERSION = '33';

const state = {
  inventory: [], isotopes: new Map(), groups: [], filter: 'all', query: '',
  date: todayIso(), deferredInstall: null, editingInventoryIndex: null, loadWarnings: []
};
const $ = id => document.getElementById(id);

function todayIso() {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function parseCsv(text) {
  const first = text.split(/\r?\n/, 1)[0] || '';
  const delimiter = (first.match(/;/g) || []).length >= (first.match(/,/g) || []).length ? ';' : ',';
  const rows = [];
  let row = [], field = '', quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index], next = text[index + 1];
    if (char === '"' && quoted && next === '"') { field += '"'; index += 1; }
    else if (char === '"') quoted = !quoted;
    else if (char === delimiter && !quoted) { row.push(field.trim()); field = ''; }
    else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && next === '\n') index += 1;
      row.push(field.trim());
      if (row.some(Boolean)) rows.push(row);
      row = []; field = '';
    } else field += char;
  }
  row.push(field.trim());
  if (row.some(Boolean)) rows.push(row);
  if (rows.length < 2) return [];
  const headers = rows[0].map(header => header.replace(/^\ufeff/, ''));
  return rows.slice(1).map(values => Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ''])));
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}
function num(value) {
  if (value === '' || value == null) return null;
  const number = Number(String(value).replace(',', '.'));
  return Number.isFinite(number) ? number : null;
}
function dateValue(iso) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(iso || ''))) return null;
  const [year, month, day] = iso.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day, 12));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day ? date : null;
}
function formatDate(iso) {
  const date = dateValue(iso);
  return date ? date.toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric', timeZone: 'UTC' }) : 'No indicada';
}
function formatNumber(value, digits = 2) {
  if (value == null || !Number.isFinite(value)) return '—';
  const absolute = Math.abs(value);
  if ((absolute > 0 && absolute < 0.001) || absolute >= 1e12) return value.toExponential(3).replace('.', ',');
  return new Intl.NumberFormat('es-ES', { maximumFractionDigits: digits, minimumFractionDigits: 0 }).format(value);
}
function smartActivity(value) {
  if (value == null || !Number.isFinite(value)) return { value: '—', unit: 'Bq' };
  const absolute = Math.abs(value);
  if (absolute >= 1e9) return { value: formatNumber(value / 1e9, 3), unit: 'GBq' };
  if (absolute >= 1e6) return { value: formatNumber(value / 1e6, 3), unit: 'MBq' };
  if (absolute >= 10_000) return { value: formatNumber(value / 1000, 3), unit: 'kBq' };
  return { value: formatNumber(value, absolute < 10 ? 3 : 2), unit: 'Bq' };
}
function typeCategory(item) { return String(item?.tipo || '').startsWith('fuente_') ? 'point' : 'material'; }

function normalizeInventoryRecord(record) {
  if (!record || typeof record !== 'object') return null;
  return {
    tipo: String(record.tipo || 'muestra_contaminada'),
    identificacion: String(record.identificacion || '').trim(), radionuclido: String(record.radionuclido || '').trim(),
    masa_g: String(record.masa_g ?? '').trim(), actividad_especifica_bq_g: String(record.actividad_especifica_bq_g ?? '').trim(),
    incertidumbre_especifica_bq_g: String(record.incertidumbre_especifica_bq_g ?? '').trim(),
    operador_actividad: record.operador_actividad === '<' ? '<' : '=',
    actividad_referencia_bq: String(record.actividad_referencia_bq ?? '').trim(),
    incertidumbre_actividad_bq: String(record.incertidumbre_actividad_bq ?? '').trim(),
    fecha_referencia: String(record.fecha_referencia || '').trim(), tipo_incertidumbre: String(record.tipo_incertidumbre || '').trim(),
    documento: String(record.documento || '').trim(), observaciones: String(record.observaciones || '').trim()
  };
}
function normalizeIsotopeRecord(record) {
  if (!record || typeof record !== 'object') return null;
  return { ...record, isotopo: String(record.isotopo || '').trim(), semivida_valor: String(record.semivida_valor ?? '').trim(), semivida_unidad: String(record.semivida_unidad || 'anos').trim().toLowerCase(), fuente: String(record.fuente || '').trim() };
}
function readStoredArray(key, fallback, label) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) throw new Error();
    return parsed;
  } catch {
    state.loadWarnings.push(`Los datos guardados de ${label} estaban dañados; se han cargado los datos originales.`);
    return fallback;
  }
}
function migrateInventory(records) {
  const correctedIds = new Map([['K-40', 'O21121-K-40'], ['Co-60', 'O21121-Co-60'], ['Cs-137', 'O21121-Cs-137'], ['Th-232', 'O21121-Th-232'], ['Ra-226', 'O21121-Ra-226'], ['BG', 'O21121-BG']]);
  let changed = false;
  const migrated = records.map(record => {
    if (typeCategory(record) === 'material' && correctedIds.has(record.identificacion)) {
      changed = true;
      return { ...record, identificacion: correctedIds.get(record.identificacion) };
    }
    return record;
  });
  return { records: migrated, changed };
}

function halfLifeData(item) {
  const isotope = state.isotopes.get(item.radionuclido), value = num(isotope?.semivida_valor);
  if (!(value > 0)) return null;
  const unit = String(isotope.semivida_unidad || '').toLowerCase();
  let years;
  if (unit.startsWith('dia')) years = value / YEAR_DAYS;
  else if (unit.startsWith('hora')) years = value / (YEAR_DAYS * 24);
  else if (unit.startsWith('ano') || unit.startsWith('año')) years = value;
  else return null;
  return Number.isFinite(years) && years > 0 ? { value, unit, years } : null;
}
function halfLifeLabel(item) {
  const half = halfLifeData(item);
  if (!half) return 'no disponible';
  const unitLabel = half.unit.startsWith('dia') ? 'días' : half.unit.startsWith('hora') ? 'horas' : 'años';
  return `${formatNumber(half.value, half.value > 10_000 ? 0 : 4)} ${unitLabel}`;
}
function calculation(item) {
  const reference = num(item.actividad_referencia_bq), specific = num(item.actividad_especifica_bq_g);
  const uncertainty = num(item.incertidumbre_actividad_bq), specificUncertainty = num(item.incertidumbre_especifica_bq_g);
  const half = halfLifeData(item), referenceDate = dateValue(item.fecha_referencia), targetDate = dateValue(state.date);
  const unavailable = reason => ({ available: false, reason, reference, specific, half: half?.years ?? null, isLimit: item.operador_actividad === '<' });
  if (reference == null || reference < 0) return unavailable('Falta una actividad de referencia válida');
  if (!referenceDate) return unavailable('Falta una fecha de referencia válida');
  if (!targetDate) return unavailable('La fecha de cálculo no es válida');
  if (!half) return unavailable('Falta una semivida válida');
  const days = (targetDate - referenceDate) / DAY_MS, factor = Math.pow(2, -days / (half.years * YEAR_DAYS));
  const activity = reference * factor, specificActivity = specific == null ? null : specific * factor;
  const currentUncertainty = uncertainty == null ? null : uncertainty * factor;
  const currentSpecificUncertainty = specificUncertainty == null ? null : specificUncertainty * factor;
  if (![factor, activity, specificActivity, currentUncertainty, currentSpecificUncertainty].filter(value => value != null).every(Number.isFinite)) return unavailable('El resultado queda fuera del rango calculable');
  return { available: true, reference, specific, half: half.years, days, factor, activity, specificActivity, uncertainty: currentUncertainty, specificUncertainty: currentSpecificUncertainty, isLimit: item.operador_actividad === '<' };
}

function groupInventory() {
  const map = new Map();
  for (const item of state.inventory) {
    const type = typeCategory(item), key = `${type}|${item.identificacion}`;
    if (!map.has(key)) map.set(key, { key, type, id: item.identificacion, items: [] });
    map.get(key).items.push(item);
  }
  state.groups = [...map.values()];
}
function groupTitle(group) {
  const names = [...new Set(group.items.map(item => item.radionuclido || 'Isótopo sin nombre'))];
  return `${names.length > 2 ? names.join(' / ') : names.join(' + ')} · ${group.type === 'point' ? 'NS ' : ''}${group.id || 'Sin identificador'}`;
}
function visibleGroups() {
  const query = state.query.toLocaleLowerCase('es');
  return state.groups.filter(group => (state.filter === 'all' || group.type === state.filter) && (!query || [group.id, ...group.items.flatMap(item => [item.radionuclido, item.observaciones])].join(' ').toLocaleLowerCase('es').includes(query)));
}
function sourceType(group) {
  if (group.type === 'point') return group.items.length > 1 ? 'Fuente puntual mixta' : 'Fuente puntual';
  if (group.items.some(item => item.tipo === 'blanco_bg')) return 'Blanco de fondo';
  return `Muestra contaminada con ${[...new Set(group.items.map(item => item.radionuclido))].join(' / ')}`;
}

function isotopeRow(item) {
  const result = calculation(item), reference = smartActivity(result.reference), current = smartActivity(result.activity);
  const prefix = result.isLimit ? '&lt; ' : '', inventoryIndex = state.inventory.indexOf(item);
  let currentHtml;
  if (result.available) {
    const detail = result.uncertainty != null && !result.isLimit ? `± ${smartActivity(result.uncertainty).value} ${smartActivity(result.uncertainty).unit}` : `${formatNumber(result.factor * 100, 2)} % del valor de referencia`;
    currentHtml = `<strong class="${result.isLimit ? 'limit-value' : ''}">${prefix}${current.value} ${current.unit}</strong><small>${detail}</small>`;
  } else currentHtml = `<strong class="unavailable-value">No calculable</strong><small>${escapeHtml(result.reason)}</small>`;
  const specificReference = result.specific != null ? `${item.operador_actividad === '<' ? '&lt; ' : ''}${formatNumber(result.specific, 3)} Bq/g` : '';
  const specificNow = result.available && result.specificActivity != null ? `${result.isLimit ? '&lt; ' : ''}${formatNumber(result.specificActivity, 3)} Bq/g` : '';
  const specificUncertainty = result.available && result.specificUncertainty != null && !result.isLimit ? ` ± ${formatNumber(result.specificUncertainty, 3)} Bq/g` : '';
  const referenceUncertainty = num(item.incertidumbre_actividad_bq);
  const referenceDetails = [specificReference, formatDate(item.fecha_referencia), referenceUncertainty != null && item.operador_actividad !== '<' ? `± ${smartActivity(referenceUncertainty).value} ${smartActivity(referenceUncertainty).unit}` : ''].filter(Boolean).join(' · ');
  return `<div class="nuclide-row"><div class="nuclide-name">${escapeHtml(item.radionuclido || 'Sin isótopo')}<small>T½ ${escapeHtml(halfLifeLabel(item))}</small><button class="inline-action" type="button" data-action="edit-item" data-index="${inventoryIndex}" aria-label="Editar ${escapeHtml(item.radionuclido)} de ${escapeHtml(item.identificacion)}">Editar registro</button></div><div class="value-block"><span>Actividad a ${escapeHtml(formatDate(state.date))}</span>${currentHtml}${specificNow ? `<small>${specificNow}${specificUncertainty}</small>` : ''}</div><div class="value-block"><span>Valor de referencia</span><strong>${item.operador_actividad === '<' ? '&lt; ' : ''}${reference.value} ${reference.unit}</strong><small>${referenceDetails || 'Sin detalles de referencia'}</small></div></div>`;
}
function card(group) {
  const mass = num(group.items[0].masa_g), recordsLabel = group.items.length === 1 ? '1 isótopo' : `${group.items.length} isótopos`;
  return `<article class="source-card ${group.type}"><header><div class="card-heading"><h3>${escapeHtml(groupTitle(group))}</h3><span class="type-badge">${escapeHtml(sourceType(group))}</span></div><button class="small-button danger card-remove" type="button" data-action="delete-group" data-group-key="${escapeHtml(group.key)}" aria-label="Quitar ${escapeHtml(groupTitle(group))}">Quitar</button></header>${group.items.map(isotopeRow).join('')}<div class="metadata"><div><span>Identificador</span><strong>${escapeHtml(group.id || 'Sin identificar')}</strong></div><div><span>Masa</span><strong>${mass != null ? `${formatNumber(mass, 2)} g` : 'No aplica'}</strong></div><div><span>Contenido</span><strong>${recordsLabel}</strong></div></div></article>`;
}
function render() {
  const groups = visibleGroups(), point = state.groups.filter(group => group.type === 'point').length, material = state.groups.filter(group => group.type === 'material').length;
  $('countAll').textContent = state.groups.length; $('countPoint').textContent = point; $('countMaterial').textContent = material;
  $('resultCount').textContent = groups.length === 1 ? '1 elemento visible' : `${groups.length} elementos visibles`;
  $('listTitle').textContent = state.filter === 'point' ? 'Fuentes puntuales' : state.filter === 'material' ? 'Material contaminado' : 'Inventario completo';
  $('sourceList').innerHTML = groups.map(card).join(''); $('emptyState').classList.toggle('hidden', groups.length > 0);
  $('summary').innerHTML = `<div class="summary-item"><span>Fuentes puntuales</span><strong>${point}</strong></div><div class="summary-item"><span>Materiales</span><strong>${material}</strong></div>`;
  const selectedDate = dateValue(state.date), today = dateValue(todayIso()), delta = selectedDate && today ? Math.round((selectedDate - today) / DAY_MS) : null;
  $('dateSummary').textContent = delta == null ? 'Selecciona una fecha válida' : delta === 0 ? 'Actividad calculada para hoy' : delta > 0 ? `${delta} días después de hoy` : `${Math.abs(delta)} días antes de hoy`;
}

function renderIsotopes() {
  const rows = [...state.isotopes.values()].sort((a, b) => a.isotopo.localeCompare(b.isotopo, 'es'));
  $('isotopeTable').innerHTML = `<div class="isotope-table-row head" role="row"><span role="columnheader">Isótopo</span><span role="columnheader">Semivida</span><span role="columnheader">Unidad</span><span role="columnheader">Fuente</span><span role="columnheader">Acciones</span></div>${rows.map(isotope => `<div class="isotope-table-row" role="row"><strong role="cell">${escapeHtml(isotope.isotopo)}</strong><span role="cell">${formatNumber(num(isotope.semivida_valor), num(isotope.semivida_valor) > 10_000 ? 0 : 4)}</span><span role="cell">${escapeHtml(isotope.semivida_unidad)}</span><span role="cell">${escapeHtml(isotope.fuente || '—')}</span><span class="isotope-actions" role="cell"><button class="small-button" type="button" data-action="edit" data-isotope="${escapeHtml(isotope.isotopo)}" aria-label="Editar ${escapeHtml(isotope.isotopo)}">Editar</button><button class="small-button danger" type="button" data-action="delete" data-isotope="${escapeHtml(isotope.isotopo)}" aria-label="Quitar ${escapeHtml(isotope.isotopo)}">Quitar</button></span></div>`).join('')}`;
  $('isotopeTable').setAttribute('role', 'table');
}
function commitInventory(nextInventory) {
  try { localStorage.setItem(STORAGE_INVENTORY, JSON.stringify(nextInventory)); localStorage.setItem(STORAGE_DATA_VERSION, DATA_VERSION); }
  catch { toast('No se han podido guardar los cambios en este dispositivo.'); return false; }
  state.inventory = nextInventory; groupInventory(); render(); return true;
}
function commitIsotopes(nextIsotopes) {
  try { localStorage.setItem(STORAGE_ISOTOPES, JSON.stringify([...nextIsotopes.values()])); }
  catch { toast('No se ha podido guardar la tabla de isótopos.'); return false; }
  state.isotopes = nextIsotopes; renderIsotopes(); render(); return true;
}

function updateInventoryFields() {
  const material = $('inventoryType').value === 'material_contaminado';
  document.querySelectorAll('.material-field').forEach(field => field.classList.toggle('hidden', !material));
  $('inventoryMass').required = material;
  if (!material) { $('inventoryMass').value = ''; $('inventorySpecificActivity').value = ''; }
}
function populateInventoryForm(item) {
  $('inventoryType').value = typeCategory(item) === 'point' ? 'fuente_puntual' : 'material_contaminado';
  $('inventoryId').value = item.identificacion;
  if (!state.isotopes.has(item.radionuclido)) $('inventoryIsotope').insertAdjacentHTML('beforeend', `<option value="${escapeHtml(item.radionuclido)}">${escapeHtml(item.radionuclido)}</option>`);
  $('inventoryIsotope').value = item.radionuclido; $('inventoryReferenceDate').value = dateValue(item.fecha_referencia) ? item.fecha_referencia : '';
  $('inventoryActivity').value = item.actividad_referencia_bq; $('inventoryOperator').value = item.operador_actividad === '<' ? '<' : '=';
  $('inventoryMass').value = item.masa_g; $('inventorySpecificActivity').value = item.actividad_especifica_bq_g;
  $('inventoryUncertainty').value = item.incertidumbre_actividad_bq; $('inventoryUncertaintyType').value = item.tipo_incertidumbre.replaceAll('_', ' '); $('inventoryNotes').value = item.observaciones;
}
function openInventoryDialog(index = null) {
  $('inventoryForm').reset(); state.editingInventoryIndex = Number.isInteger(index) ? index : null;
  $('inventoryIsotope').innerHTML = [...state.isotopes.keys()].sort((a, b) => a.localeCompare(b, 'es')).map(name => `<option value="${escapeHtml(name)}">${escapeHtml(name)}</option>`).join('');
  $('inventoryStatus').classList.add('hidden');
  const editing = state.editingInventoryIndex != null && state.inventory[state.editingInventoryIndex];
  $('inventoryDialogTitle').textContent = editing ? 'Editar registro' : 'Añadir al inventario';
  $('inventoryDialogSubtitle').textContent = editing ? `${editing.radionuclido} · ${editing.identificacion}` : 'Nueva fuente puntual o muestra contaminada';
  $('saveInventory').textContent = editing ? 'Guardar cambios' : 'Añadir al inventario';
  if (editing) populateInventoryForm(editing);
  updateInventoryFields(); $('inventoryDialog').showModal(); requestAnimationFrame(() => $('inventoryId').focus());
}
function closeInventoryDialog() { if ($('inventoryDialog').open) $('inventoryDialog').close(); state.editingInventoryIndex = null; }
function inventoryError(message, field) {
  $('inventoryStatus').textContent = message; $('inventoryStatus').classList.remove('hidden');
  if (field) { field.setAttribute('aria-invalid', 'true'); field.focus(); }
}
function clearInventoryErrors() { $('inventoryStatus').classList.add('hidden'); $('inventoryForm').querySelectorAll('[aria-invalid="true"]').forEach(field => field.removeAttribute('aria-invalid')); }

function saveInventory(event) {
  event.preventDefault(); clearInventoryErrors();
  const editingIndex = state.editingInventoryIndex, previous = editingIndex == null ? null : state.inventory[editingIndex];
  const type = $('inventoryType').value, category = type === 'fuente_puntual' ? 'point' : 'material';
  const id = $('inventoryId').value.trim(), isotope = $('inventoryIsotope').value, referenceDate = $('inventoryReferenceDate').value;
  const operator = $('inventoryOperator').value === '<' ? '<' : '=';
  const mass = category === 'material' ? num($('inventoryMass').value) : null;
  let specific = category === 'material' ? num($('inventorySpecificActivity').value) : null, activity = num($('inventoryActivity').value);
  const uncertainty = num($('inventoryUncertainty').value);
  if (!id) return inventoryError('Introduce el identificador o número de serie.', $('inventoryId'));
  if (id.length > 120) return inventoryError('El identificador no puede superar 120 caracteres.', $('inventoryId'));
  if (!isotope) return inventoryError('Selecciona un isótopo.', $('inventoryIsotope'));
  if (!dateValue(referenceDate)) return inventoryError('Introduce una fecha de referencia válida.', $('inventoryReferenceDate'));
  if (category === 'material' && !(mass > 0)) return inventoryError('La masa debe ser mayor que cero para el material contaminado.', $('inventoryMass'));
  if (activity != null && activity < 0) return inventoryError('La actividad no puede ser negativa.', $('inventoryActivity'));
  if (specific != null && specific < 0) return inventoryError('La actividad específica no puede ser negativa.', $('inventorySpecificActivity'));
  if (uncertainty != null && uncertainty < 0) return inventoryError('La incertidumbre no puede ser negativa.', $('inventoryUncertainty'));
  if (category === 'material' && activity != null && specific != null) {
    const calculatedTotal = specific * mass, tolerance = Math.max(0.05, Math.abs(activity) * 0.005);
    if (Math.abs(activity - calculatedTotal) > tolerance) return inventoryError(`Los valores no coinciden: ${formatNumber(specific, 3)} Bq/g × ${formatNumber(mass, 2)} g = ${formatNumber(calculatedTotal, 2)} Bq.`, $('inventorySpecificActivity'));
  }
  if (activity == null && specific != null && mass != null) activity = specific * mass;
  if (activity == null) return inventoryError('Introduce la actividad en Bq o, para material, la actividad en Bq/g.', $('inventoryActivity'));
  if (category === 'material' && specific == null) specific = activity / mass;
  const duplicate = state.inventory.some((item, index) => index !== editingIndex && typeCategory(item) === category && item.identificacion === id && item.radionuclido === isotope);
  if (duplicate) return inventoryError('Ese identificador ya contiene este isótopo.', $('inventoryIsotope'));
  const related = state.inventory.filter((item, index) => index !== editingIndex && typeCategory(item) === category && item.identificacion === id);
  const existingMass = num(related[0]?.masa_g);
  if (category === 'material' && existingMass != null && Math.abs(existingMass - mass) > 1e-9) return inventoryError(`La muestra ${id} ya está registrada con una masa de ${formatNumber(existingMass, 2)} g.`, $('inventoryMass'));
  const preservedType = previous && typeCategory(previous) === category ? previous.tipo : null;
  const nextItem = {
    tipo: preservedType || (category === 'point' ? 'fuente_puntual' : 'muestra_contaminada'), identificacion: id, radionuclido: isotope,
    masa_g: category === 'material' ? String(mass) : '', actividad_especifica_bq_g: category === 'material' ? String(specific) : '',
    incertidumbre_especifica_bq_g: category === 'material' && uncertainty != null ? String(uncertainty / mass) : '', operador_actividad: operator,
    actividad_referencia_bq: String(activity), incertidumbre_actividad_bq: uncertainty == null ? '' : String(uncertainty), fecha_referencia: referenceDate,
    tipo_incertidumbre: $('inventoryUncertaintyType').value.trim().replaceAll(' ', '_'), documento: previous?.documento || '', observaciones: $('inventoryNotes').value.trim()
  };
  const nextInventory = [...state.inventory];
  if (editingIndex == null) nextInventory.push(nextItem); else nextInventory[editingIndex] = nextItem;
  if (!commitInventory(nextInventory)) return;
  closeInventoryDialog(); toast(`${isotope} · ${id} ${editingIndex == null ? 'añadido' : 'actualizado'}.`);
}
function deleteGroup(key) {
  const group = state.groups.find(candidate => candidate.key === key);
  if (!group) return;
  const countText = group.items.length === 1 ? 'este registro' : `los ${group.items.length} isótopos de este conjunto`;
  if (!confirm(`¿Quitar ${countText}: ${groupTitle(group)}? Esta acción no se puede deshacer.`)) return;
  const nextInventory = state.inventory.filter(item => !(typeCategory(item) === group.type && item.identificacion === group.id));
  if (commitInventory(nextInventory)) toast(`${group.id || 'Registro'} eliminado.`);
}

function showIsotopeStatus(message, error = false) { const status = $('isotopeStatus'); status.textContent = message; status.classList.remove('hidden', 'error'); status.classList.toggle('error', error); }
function openIsotopeEditor(isotope = '') {
  const current = isotope ? state.isotopes.get(isotope) : null;
  $('isotopeEditorTitle').textContent = current ? 'Editar isótopo' : 'Añadir isótopo'; $('isotopeName').value = current?.isotopo || ''; $('isotopeName').disabled = Boolean(current);
  $('isotopeHalfLife').value = current?.semivida_valor || ''; $('isotopeUnit').value = current?.semivida_unidad || 'anos'; $('isotopeSource').value = current?.fuente || '';
  $('isotopeEditor').dataset.original = isotope; $('isotopeEditor').classList.remove('hidden'); $('isotopeStatus').classList.add('hidden'); $('isotopeName').focus();
}
function closeIsotopeEditor() { $('isotopeEditor').classList.add('hidden'); $('isotopeEditor').dataset.original = ''; }
function saveIsotope() {
  const original = $('isotopeEditor').dataset.original, name = $('isotopeName').value.trim(), half = num($('isotopeHalfLife').value), unit = $('isotopeUnit').value, source = $('isotopeSource').value.trim();
  if (!name) return showIsotopeStatus('Introduce el nombre del isótopo.', true);
  if (name.length > 40) return showIsotopeStatus('El nombre del isótopo no puede superar 40 caracteres.', true);
  if (!(half > 0)) return showIsotopeStatus('La semivida debe ser un número mayor que cero.', true);
  const duplicate = [...state.isotopes.keys()].some(existing => existing.toLocaleLowerCase('es') === name.toLocaleLowerCase('es') && existing !== original);
  if (duplicate) return showIsotopeStatus('Ese isótopo ya existe. Utiliza Editar.', true);
  const key = original || name, nextIsotopes = new Map(state.isotopes);
  nextIsotopes.set(key, { ...(nextIsotopes.get(key) || {}), isotopo: key, semivida_valor: String(half), semivida_unidad: unit, fuente: source });
  if (!commitIsotopes(nextIsotopes)) return;
  closeIsotopeEditor(); showIsotopeStatus(`${original ? 'Isótopo actualizado' : 'Isótopo añadido'} correctamente.`);
}
function deleteIsotope(name) {
  const usedBy = state.inventory.filter(item => item.radionuclido === name);
  if (usedBy.length) return showIsotopeStatus(`No se puede quitar ${name}: se usa en ${usedBy.length} registro${usedBy.length === 1 ? '' : 's'} del inventario.`, true);
  if (!confirm(`¿Quieres quitar ${name} de la tabla de isótopos?`)) return;
  const nextIsotopes = new Map(state.isotopes); nextIsotopes.delete(name);
  if (!commitIsotopes(nextIsotopes)) return;
  closeIsotopeEditor(); showIsotopeStatus(`${name} eliminado.`);
}

function reportRows(groups) {
  return groups.flatMap(group => group.items.map(item => {
    const result = calculation(item), current = smartActivity(result.activity), reference = smartActivity(num(item.actividad_referencia_bq));
    const uncertainty = result.uncertainty != null && !result.isLimit ? `<small>± ${smartActivity(result.uncertainty).value} ${smartActivity(result.uncertainty).unit}</small>` : '';
    const currentValue = result.available ? `${result.isLimit ? '&lt; ' : ''}${current.value} ${current.unit}${uncertainty}` : `<span class="report-warning">${escapeHtml(result.reason)}</span>`;
    const specificValue = result.specificActivity != null ? `${result.isLimit ? '&lt; ' : ''}${formatNumber(result.specificActivity, 3)} Bq/g${result.specificUncertainty != null && !result.isLimit ? `<small>± ${formatNumber(result.specificUncertainty, 3)} Bq/g</small>` : ''}` : '—';
    return `<tr><td>${escapeHtml(group.id)}</td><td>${escapeHtml(item.radionuclido)}</td><td>${num(item.masa_g) != null ? formatNumber(num(item.masa_g), 2) : '—'}</td><td>${item.operador_actividad === '<' ? '&lt; ' : ''}${reference.value} ${reference.unit}</td><td>${currentValue}</td><td>${specificValue}</td><td>${escapeHtml(formatDate(item.fecha_referencia))}</td></tr>`;
  }));
}
function buildReport(visibleOnly = false) {
  const groups = visibleOnly ? visibleGroups() : state.groups, point = groups.filter(group => group.type === 'point'), material = groups.filter(group => group.type === 'material');
  const section = (title, items) => items.length ? `<section class="report-section"><h2>${title}</h2><table class="report-table"><thead><tr><th>Identificador/NS</th><th>Isótopo</th><th>Masa (g)</th><th>Actividad de referencia</th><th>Actividad calculada</th><th>Actividad específica</th><th>Fecha de referencia</th></tr></thead><tbody>${reportRows(items).join('')}</tbody></table></section>` : '';
  $('printReportView').innerHTML = `<div class="report-head"><img class="report-logo" src="assets/brand/at-logo-horizontal.png?v=33" alt="Aplicaciones Tecnológicas Radiation Protection &amp; Medical"><div class="report-title"><h1>Cálculo de actividades</h1><p>Fecha de cálculo: ${escapeHtml(formatDate(state.date))}</p></div></div><div class="report-summary"><div><span>Fuentes puntuales</span><strong>${point.length}</strong></div><div><span>Materiales</span><strong>${material.length}</strong></div><div><span>Isótopos registrados</span><strong>${state.isotopes.size}</strong></div></div>${section('Fuentes puntuales', point)}${section('Material contaminado', material)}<div class="report-footer"><strong>APLICACIONES TECNOLÓGICAS · RADIATION PROTECTION &amp; MEDICAL</strong><br>Cálculo: A(t) = A₀ × 2^(-(t-t₀)/T½). Las incertidumbres de actividad se escalan con el mismo factor de decaimiento; no se incluyen incertidumbres adicionales de masa o semivida. Los valores precedidos por &lt; son límites superiores, no actividades medidas. Documento generado localmente.</div>`;
  return groups;
}
function buildShareText(groups) {
  const lines = groups.flatMap(group => group.items.map(item => {
    const result = calculation(item);
    if (!result.available) return `${group.id} · ${item.radionuclido}: no calculable (${result.reason})`;
    const activity = smartActivity(result.activity), specific = result.specificActivity == null ? '' : ` · ${result.isLimit ? '< ' : ''}${formatNumber(result.specificActivity, 3)} Bq/g`;
    return `${group.id} · ${item.radionuclido}: ${result.isLimit ? '< ' : ''}${activity.value} ${activity.unit}${specific}`;
  }));
  return `APLICACIONES TECNOLÓGICAS · RADIATION PROTECTION & MEDICAL\n\nCálculo de actividades\nFecha de cálculo: ${formatDate(state.date)}\n\n${lines.join('\n')}\n\nDocumento generado con Cálculo de decaimientos.`;
}
function toast(message) { $('toast').textContent = message; $('toast').classList.remove('hidden'); clearTimeout(toast.timer); toast.timer = setTimeout(() => $('toast').classList.add('hidden'), 3600); }

async function init() {
  try {
    const [inventoryResponse, isotopeResponse] = await Promise.all([fetch('inventario_radiactivo.csv'), fetch('isotopos.csv')]);
    if (!inventoryResponse.ok || !isotopeResponse.ok) throw new Error('No se han podido descargar los datos base');
    const [inventoryText, isotopeText] = await Promise.all([inventoryResponse.text(), isotopeResponse.text()]);
    const baseInventory = parseCsv(inventoryText).map(normalizeInventoryRecord).filter(Boolean), baseIsotopes = parseCsv(isotopeText).map(normalizeIsotopeRecord).filter(Boolean);
    const storedInventory = readStoredArray(STORAGE_INVENTORY, baseInventory, 'inventario').map(normalizeInventoryRecord).filter(Boolean);
    const storedIsotopes = readStoredArray(STORAGE_ISOTOPES, baseIsotopes, 'isótopos').map(normalizeIsotopeRecord).filter(Boolean);
    const migrated = migrateInventory(storedInventory); state.inventory = migrated.records;
    for (const isotope of storedIsotopes) if (isotope.isotopo) state.isotopes.set(isotope.isotopo, isotope);
    if (migrated.changed || localStorage.getItem(STORAGE_DATA_VERSION) !== DATA_VERSION) {
      try { localStorage.setItem(STORAGE_INVENTORY, JSON.stringify(state.inventory)); localStorage.setItem(STORAGE_DATA_VERSION, DATA_VERSION); }
      catch { state.loadWarnings.push('No se ha podido completar la actualización local de los datos.'); }
    }
    groupInventory(); renderIsotopes(); render();
    if (state.loadWarnings.length) toast(state.loadWarnings.join(' '));
  } catch (error) {
    $('sourceList').innerHTML = `<div class="status error">No se han podido cargar los datos: ${escapeHtml(error.message || 'error desconocido')}.</div>`;
  }
}

$('calculationDate').value = state.date; $('calculationDate').max = '9999-12-31'; $('calculationDate').setAttribute('aria-describedby', 'dateSummary');
$('calculationDate').addEventListener('change', event => {
  if (dateValue(event.target.value)) { state.date = event.target.value; render(); }
  else { event.target.value = state.date; toast('Selecciona una fecha válida.'); }
});
$('searchInput').addEventListener('input', event => { state.query = event.target.value.trim(); render(); });
document.querySelectorAll('.tab').forEach(tab => tab.addEventListener('click', () => {
  document.querySelectorAll('.tab').forEach(candidate => { const selected = candidate === tab; candidate.classList.toggle('active', selected); candidate.setAttribute('aria-pressed', String(selected)); });
  state.filter = tab.dataset.filter; render();
}));
$('sourceList').addEventListener('click', event => {
  const button = event.target.closest('button[data-action]'); if (!button) return;
  if (button.dataset.action === 'edit-item') openInventoryDialog(Number(button.dataset.index));
  if (button.dataset.action === 'delete-group') deleteGroup(button.dataset.groupKey);
});
$('isotopesButton').addEventListener('click', () => { closeIsotopeEditor(); $('isotopeStatus').classList.add('hidden'); $('isotopesDialog').showModal(); });
$('reportButton').addEventListener('click', () => $('reportDialog').showModal()); $('inventoryButton').addEventListener('click', () => openInventoryDialog());
$('inventoryType').addEventListener('change', updateInventoryFields); $('inventoryForm').addEventListener('submit', saveInventory);
$('cancelInventory').addEventListener('click', closeInventoryDialog); $('closeInventory').addEventListener('click', closeInventoryDialog);
$('addIsotope').addEventListener('click', () => openIsotopeEditor()); $('cancelIsotopeEdit').addEventListener('click', closeIsotopeEditor); $('saveIsotope').addEventListener('click', saveIsotope);
$('isotopeTable').addEventListener('click', event => { const button = event.target.closest('button[data-action]'); if (!button) return; const name = button.dataset.isotope; if (button.dataset.action === 'edit') openIsotopeEditor(name); if (button.dataset.action === 'delete') deleteIsotope(name); });
$('printReport').addEventListener('click', async () => {
  buildReport($('reportVisibleOnly').checked); $('reportDialog').close(); await document.fonts?.ready;
  await Promise.all([...$('printReportView').querySelectorAll('img')].map(image => image.decode?.().catch(() => {}))); window.print();
});
$('shareReport').addEventListener('click', async () => {
  const groups = buildReport($('reportVisibleOnly').checked), text = buildShareText(groups);
  if (navigator.share) {
    try { await navigator.share({ title: 'Cálculo de actividades · Aplicaciones Tecnológicas', text }); }
    catch (error) { if (error.name !== 'AbortError') toast('No se ha podido compartir el resumen.'); }
  } else if (navigator.clipboard?.writeText) {
    try { await navigator.clipboard.writeText(text); toast('Resumen completo copiado al portapapeles.'); }
    catch { toast('No se ha podido copiar el resumen.'); }
  } else toast('Compartir no está disponible en este navegador.');
});
window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); state.deferredInstall = event; $('installButton').classList.remove('hidden'); });
$('installButton').addEventListener('click', async () => { if (!state.deferredInstall) return; state.deferredInstall.prompt(); await state.deferredInstall.userChoice; state.deferredInstall = null; $('installButton').classList.add('hidden'); });
if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js?v=33', { scope: './' }).catch(() => toast('El modo sin conexión no está disponible.')));
init();
