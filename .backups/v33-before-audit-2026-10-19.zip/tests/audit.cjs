const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const baseUrl = process.env.APP_URL || 'http://127.0.0.1:8080/?v=33';
const outputDir = path.join(__dirname, 'output');
fs.mkdirSync(outputDir, { recursive: true });

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

async function fillBaseSource(page, id, activity = '100') {
  await page.getByRole('button', { name: 'Añadir fuente o material' }).click();
  await page.locator('#inventoryId').fill(id);
  await page.locator('#inventoryReferenceDate').fill('2026-01-01');
  await page.locator('#inventoryActivity').fill(activity);
}

(async () => {
  const executablePath = fs.existsSync('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe')
    ? 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
    : undefined;
  const browser = await chromium.launch({ headless: true, executablePath });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, locale: 'es-ES' });
  const page = await context.newPage();
  const runtimeErrors = [];
  page.on('pageerror', error => runtimeErrors.push(`pageerror: ${error.message}`));
  page.on('console', message => { if (message.type() === 'error') runtimeErrors.push(`console: ${message.text()}`); });

  await page.goto(baseUrl, { waitUntil: 'networkidle' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.locator('.source-card').first().waitFor();

  assert(await page.locator('.source-card').count() === 17, 'El inventario inicial no contiene 17 elementos físicos.');
  assert(await page.locator('.source-card.point').count() === 8, 'El inventario inicial no contiene 8 fuentes puntuales.');
  assert(await page.locator('.source-card.material').count() === 9, 'El inventario inicial no contiene 9 materiales.');
  assert(await page.locator('[data-action="edit-item"]').count() >= 17, 'Faltan controles para editar registros.');
  assert(await page.locator('[data-action="delete-group"]').count() === 17, 'Faltan controles para quitar elementos físicos.');
  assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'Existe desbordamiento horizontal en escritorio.');

  await page.evaluate(() => localStorage.setItem('actividad-inventario', '{json dañado'));
  await page.reload({ waitUntil: 'networkidle' });
  await page.locator('.source-card').first().waitFor();
  assert(await page.locator('.source-card').count() === 17, 'Un localStorage dañado impide recuperar el inventario base.');
  assert((await page.locator('#toast').innerText()).includes('estaban dañados'), 'La recuperación de datos dañados no informa a la persona usuaria.');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.locator('.source-card').first().waitFor();

  await page.getByRole('button', { name: /Fuentes puntuales/ }).click();
  assert(await page.getByRole('button', { name: /Fuentes puntuales/ }).getAttribute('aria-pressed') === 'true', 'El filtro activo no actualiza aria-pressed.');
  assert(await page.getByRole('button', { name: /Todos/ }).getAttribute('aria-pressed') === 'false', 'El filtro anterior continúa marcado.');
  await page.getByRole('button', { name: /Todos/ }).click();

  await page.getByRole('button', { name: 'Tabla de isótopos' }).click();
  await page.getByRole('button', { name: 'Quitar Am-241', exact: true }).click();
  assert((await page.locator('#isotopeStatus').innerText()).includes('se usa en'), 'Se permite quitar un isótopo que utiliza el inventario.');
  await page.locator('#isotopesDialog .icon-button').click();
  assert(!(await page.locator('#isotopesDialog').evaluate(dialog => dialog.open)), 'La tabla de isótopos no se cierra con la X.');

  await page.getByRole('button', { name: 'Añadir fuente o material' }).click();
  await page.locator('#inventoryType').selectOption('material_contaminado');
  await page.locator('#inventoryMass').fill('12');
  await page.locator('#inventorySpecificActivity').fill('3');
  await page.locator('#inventoryType').selectOption('fuente_puntual');
  assert(await page.locator('#inventoryMass').inputValue() === '' && await page.locator('#inventorySpecificActivity').inputValue() === '', 'Cambiar a fuente puntual conserva datos de masa ocultos.');
  await page.locator('#cancelInventory').click();

  const xssId = '<img src=x onerror="window.__xss=1">';
  await fillBaseSource(page, xssId);
  await page.locator('#saveInventory').click();
  assert(!(await page.locator('#inventoryDialog').evaluate(dialog => dialog.open)), 'El alta válida no cierra el diálogo.');
  assert(await page.locator('.source-card h3').filter({ hasText: xssId }).count() === 1, 'El identificador introducido no se muestra como texto.');
  assert(await page.locator('img[src="x"]').count() === 0, 'Se ha producido una inyección HTML persistente.');
  assert(await page.evaluate(() => !window.__xss), 'Se ha ejecutado contenido introducido por el usuario.');

  await fillBaseSource(page, 'NEGATIVE-AUDIT', '-100');
  await page.locator('#inventoryUncertainty').fill('-5');
  await page.locator('#saveInventory').click();
  assert(await page.locator('#inventoryDialog').evaluate(dialog => dialog.open), 'Se han aceptado magnitudes negativas.');
  assert((await page.locator('#inventoryStatus').innerText()).includes('no puede ser negativa'), 'Falta un error comprensible para magnitudes negativas.');
  await page.locator('#cancelInventory').click();

  await page.getByRole('button', { name: 'Añadir fuente o material' }).click();
  await page.locator('#inventoryType').selectOption('material_contaminado');
  await page.locator('#inventoryId').fill('INCONSISTENT-AUDIT');
  await page.locator('#inventoryReferenceDate').fill('2026-01-01');
  await page.locator('#inventoryMass').fill('10');
  await page.locator('#inventoryActivity').fill('100');
  await page.locator('#inventorySpecificActivity').fill('20');
  await page.locator('#saveInventory').click();
  assert((await page.locator('#inventoryStatus').innerText()).includes('no coinciden'), 'No se detecta la incoherencia entre Bq y Bq/g.');
  await page.locator('#cancelInventory').click();

  await page.locator('[data-action="edit-item"]').first().click();
  assert((await page.locator('#inventoryDialogTitle').innerText()) === 'Editar registro', 'El modo de edición no se abre correctamente.');
  await page.locator('#cancelInventory').click();

  page.once('dialog', dialog => dialog.accept());
  const beforeDelete = await page.locator('.source-card').count();
  await page.locator('[data-action="delete-group"]').first().click();
  assert(await page.locator('.source-card').count() === beforeDelete - 1, 'Quitar no elimina el elemento confirmado.');

  await page.getByRole('button', { name: 'Generar informe' }).click();
  await page.locator('#shareReport').click();
  await page.waitForTimeout(100);
  assert((await page.locator('#printReportView h1').innerText()) === 'Cálculo de actividades', 'El informe no se genera.');
  assert(await page.locator('#printReportView tbody tr').count() > 0, 'El informe no contiene filas.');
  assert((await page.locator('#printReportView').innerText()).includes('Fecha de cálculo'), 'El informe no contiene la fecha de cálculo.');

  await page.emulateMedia({ media: 'print' });
  await page.pdf({ path: path.join(outputDir, 'informe-audit.pdf'), format: 'A4', printBackground: true });
  await page.emulateMedia({ media: 'screen' });

  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle' });
  await page.locator('.source-card').first().waitFor();
  assert(await page.locator('.source-card').count() === 17, 'La recuperación de datos originales no funciona.');

  for (const viewport of [{ width: 320, height: 700 }, { width: 390, height: 844 }, { width: 768, height: 1024 }, { width: 1440, height: 900 }]) {
    await page.setViewportSize(viewport);
    await page.waitForTimeout(80);
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), `Desbordamiento horizontal a ${viewport.width}px.`);
    if (viewport.width <= 390) {
      const targetHeights = await page.locator('.small-button').evaluateAll(elements => elements.slice(0, 8).map(element => element.getBoundingClientRect().height));
      assert(targetHeights.every(height => height >= 43.5), `Hay controles táctiles menores de 44px a ${viewport.width}px.`);
    }
    await page.screenshot({ path: path.join(outputDir, `viewport-${viewport.width}.png`), fullPage: true });
  }

  await page.setViewportSize({ width: 390, height: 844 });
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await context.setOffline(true);
  await page.goto('http://127.0.0.1:8080/?offline-audit=1', { waitUntil: 'domcontentloaded' });
  await page.locator('.source-card').first().waitFor({ timeout: 5000 });
  assert(await page.locator('.source-card').count() === 17, 'La navegación con parámetros no funciona sin conexión.');
  await context.setOffline(false);

  assert(runtimeErrors.length === 0, `Errores de ejecución detectados:\n${runtimeErrors.join('\n')}`);
  console.log('AUDIT_OK: lógica, CRUD, seguridad, informe, responsive y offline');
  await browser.close();
})().catch(error => {
  console.error(error.stack || error);
  process.exitCode = 1;
});
